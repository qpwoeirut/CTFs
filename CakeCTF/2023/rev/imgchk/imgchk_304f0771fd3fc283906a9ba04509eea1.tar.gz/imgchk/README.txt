If the program does not work due to your library version, run it with
```
./ld-linux-x64-64.so.2 --library-path ./lib ./imgchk
```
or use Ubuntu 22.04 (e.g., docker)

The libraries are not modified and not important at all.
