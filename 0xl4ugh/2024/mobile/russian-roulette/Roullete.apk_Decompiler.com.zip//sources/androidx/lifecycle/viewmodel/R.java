package androidx.lifecycle.viewmodel;

public final class R {

    public static final class id {
        public static int view_tree_view_model_store_owner = 2131231021;

        private id() {
        }
    }

    private R() {
    }
}
