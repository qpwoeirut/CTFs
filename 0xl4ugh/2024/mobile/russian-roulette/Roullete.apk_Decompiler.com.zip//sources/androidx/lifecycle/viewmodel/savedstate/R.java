package androidx.lifecycle.viewmodel.savedstate;

public final class R {
    private R() {
    }
}
