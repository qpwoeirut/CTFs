package com.unity3d.player.a;

public abstract /* synthetic */ class f {
    public static /* synthetic */ int a(int i) {
        if (i == 1) {
            return -1;
        }
        if (i == 2) {
            return 0;
        }
        if (i == 3) {
            return 1;
        }
        throw null;
    }
}
