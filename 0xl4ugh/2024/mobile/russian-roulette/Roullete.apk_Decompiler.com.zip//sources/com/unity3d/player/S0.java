package com.unity3d.player;

final class S0 implements C {
    final /* synthetic */ U0 a;

    S0(U0 u0) {
        this.a = u0;
    }
}
