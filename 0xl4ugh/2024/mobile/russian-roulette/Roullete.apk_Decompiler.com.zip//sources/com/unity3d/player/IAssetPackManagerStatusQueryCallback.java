package com.unity3d.player;

interface IAssetPackManagerStatusQueryCallback {
    void onStatusResult(long j, String[] strArr, int[] iArr, int[] iArr2);
}
