package com.unity3d.player;

final class L {
    /* access modifiers changed from: private */
    public long a;
    /* access modifiers changed from: private */
    public boolean b;

    public L(long j, boolean z) {
        this.a = j;
        this.b = z;
    }
}
