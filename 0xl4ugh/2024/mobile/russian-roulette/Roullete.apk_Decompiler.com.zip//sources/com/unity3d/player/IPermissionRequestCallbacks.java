package com.unity3d.player;

public interface IPermissionRequestCallbacks {
    void onPermissionResult(String[] strArr, int[] iArr);
}
