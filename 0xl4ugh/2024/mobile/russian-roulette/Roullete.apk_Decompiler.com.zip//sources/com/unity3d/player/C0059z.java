package com.unity3d.player;

import com.unity3d.player.a.e;

/* renamed from: com.unity3d.player.z  reason: case insensitive filesystem */
final class C0059z implements e {
    final /* synthetic */ Runnable a;

    C0059z(Runnable runnable) {
        this.a = runnable;
    }
}
