package com.unity3d.player;

public @interface RequiredByNative {
}
