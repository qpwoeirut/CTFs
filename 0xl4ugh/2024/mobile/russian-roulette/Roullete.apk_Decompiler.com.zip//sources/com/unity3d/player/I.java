package com.unity3d.player;

import android.content.Context;

final class I {
    Context a;
    H b = null;

    I(Context context) {
        this.a = context;
    }
}
