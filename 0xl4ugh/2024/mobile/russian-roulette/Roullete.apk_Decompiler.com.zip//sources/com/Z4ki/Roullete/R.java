package com.Z4ki.Roullete;

public final class R {

    public static final class mipmap {
        public static int app_icon = 2131492864;
        public static int app_icon_round = 2131492865;

        private mipmap() {
        }
    }

    public static final class string {
        public static int app_name = 2131558433;
        /* added by JADX */
        public static final int FreeformWindowOrientation_landscape = 2131558400;
        /* added by JADX */
        public static final int FreeformWindowOrientation_portrait = 2131558401;
        /* added by JADX */
        public static final int FreeformWindowSize_maximize = 2131558402;
        /* added by JADX */
        public static final int FreeformWindowSize_phone = 2131558403;
        /* added by JADX */
        public static final int FreeformWindowSize_tablet = 2131558404;
        /* added by JADX */
        public static final int abc_action_bar_home_description = 2131558405;
        /* added by JADX */
        public static final int abc_action_bar_up_description = 2131558406;
        /* added by JADX */
        public static final int abc_action_menu_overflow_description = 2131558407;
        /* added by JADX */
        public static final int abc_action_mode_done = 2131558408;
        /* added by JADX */
        public static final int abc_activity_chooser_view_see_all = 2131558409;
        /* added by JADX */
        public static final int abc_activitychooserview_choose_application = 2131558410;
        /* added by JADX */
        public static final int abc_capital_off = 2131558411;
        /* added by JADX */
        public static final int abc_capital_on = 2131558412;
        /* added by JADX */
        public static final int abc_menu_alt_shortcut_label = 2131558413;
        /* added by JADX */
        public static final int abc_menu_ctrl_shortcut_label = 2131558414;
        /* added by JADX */
        public static final int abc_menu_delete_shortcut_label = 2131558415;
        /* added by JADX */
        public static final int abc_menu_enter_shortcut_label = 2131558416;
        /* added by JADX */
        public static final int abc_menu_function_shortcut_label = 2131558417;
        /* added by JADX */
        public static final int abc_menu_meta_shortcut_label = 2131558418;
        /* added by JADX */
        public static final int abc_menu_shift_shortcut_label = 2131558419;
        /* added by JADX */
        public static final int abc_menu_space_shortcut_label = 2131558420;
        /* added by JADX */
        public static final int abc_menu_sym_shortcut_label = 2131558421;
        /* added by JADX */
        public static final int abc_prepend_shortcut_label = 2131558422;
        /* added by JADX */
        public static final int abc_search_hint = 2131558423;
        /* added by JADX */
        public static final int abc_searchview_description_clear = 2131558424;
        /* added by JADX */
        public static final int abc_searchview_description_query = 2131558425;
        /* added by JADX */
        public static final int abc_searchview_description_search = 2131558426;
        /* added by JADX */
        public static final int abc_searchview_description_submit = 2131558427;
        /* added by JADX */
        public static final int abc_searchview_description_voice = 2131558428;
        /* added by JADX */
        public static final int abc_shareactionprovider_share_with = 2131558429;
        /* added by JADX */
        public static final int abc_shareactionprovider_share_with_application = 2131558430;
        /* added by JADX */
        public static final int abc_toolbar_collapse_description = 2131558431;
        /* added by JADX */
        public static final int androidx_startup = 2131558432;
        /* added by JADX */
        public static final int game_view_content_description = 2131558434;
        /* added by JADX */
        public static final int search_menu_title = 2131558435;
        /* added by JADX */
        public static final int status_bar_notification_info_overflow = 2131558436;

        private string() {
        }
    }

    /* added by JADX */
    public static final class anim {
        /* added by JADX */
        public static final int abc_fade_in = 2130771968;
        /* added by JADX */
        public static final int abc_fade_out = 2130771969;
        /* added by JADX */
        public static final int abc_grow_fade_in_from_bottom = 2130771970;
        /* added by JADX */
        public static final int abc_popup_enter = 2130771971;
        /* added by JADX */
        public static final int abc_popup_exit = 2130771972;
        /* added by JADX */
        public static final int abc_shrink_fade_out_from_bottom = 2130771973;
        /* added by JADX */
        public static final int abc_slide_in_bottom = 2130771974;
        /* added by JADX */
        public static final int abc_slide_in_top = 2130771975;
        /* added by JADX */
        public static final int abc_slide_out_bottom = 2130771976;
        /* added by JADX */
        public static final int abc_slide_out_top = 2130771977;
        /* added by JADX */
        public static final int abc_tooltip_enter = 2130771978;
        /* added by JADX */
        public static final int abc_tooltip_exit = 2130771979;
        /* added by JADX */
        public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
        /* added by JADX */
        public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
        /* added by JADX */
        public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
        /* added by JADX */
        public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
        /* added by JADX */
        public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
        /* added by JADX */
        public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
        /* added by JADX */
        public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
        /* added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
        /* added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
        /* added by JADX */
        public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
        /* added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
        /* added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
        /* added by JADX */
        public static final int fragment_fast_out_extra_slow_in = 2130771992;
    }

    /* added by JADX */
    public static final class animator {
        /* added by JADX */
        public static final int fragment_close_enter = 2130837504;
        /* added by JADX */
        public static final int fragment_close_exit = 2130837505;
        /* added by JADX */
        public static final int fragment_fade_enter = 2130837506;
        /* added by JADX */
        public static final int fragment_fade_exit = 2130837507;
        /* added by JADX */
        public static final int fragment_open_enter = 2130837508;
        /* added by JADX */
        public static final int fragment_open_exit = 2130837509;
    }

    /* added by JADX */
    public static final class attr {
        /* added by JADX */
        public static final int SharedValue = 2130903040;
        /* added by JADX */
        public static final int SharedValueId = 2130903041;
        /* added by JADX */
        public static final int actionBarDivider = 2130903042;
        /* added by JADX */
        public static final int actionBarItemBackground = 2130903043;
        /* added by JADX */
        public static final int actionBarPopupTheme = 2130903044;
        /* added by JADX */
        public static final int actionBarSize = 2130903045;
        /* added by JADX */
        public static final int actionBarSplitStyle = 2130903046;
        /* added by JADX */
        public static final int actionBarStyle = 2130903047;
        /* added by JADX */
        public static final int actionBarTabBarStyle = 2130903048;
        /* added by JADX */
        public static final int actionBarTabStyle = 2130903049;
        /* added by JADX */
        public static final int actionBarTabTextStyle = 2130903050;
        /* added by JADX */
        public static final int actionBarTheme = 2130903051;
        /* added by JADX */
        public static final int actionBarWidgetTheme = 2130903052;
        /* added by JADX */
        public static final int actionButtonStyle = 2130903053;
        /* added by JADX */
        public static final int actionDropDownStyle = 2130903054;
        /* added by JADX */
        public static final int actionLayout = 2130903055;
        /* added by JADX */
        public static final int actionMenuTextAppearance = 2130903056;
        /* added by JADX */
        public static final int actionMenuTextColor = 2130903057;
        /* added by JADX */
        public static final int actionModeBackground = 2130903058;
        /* added by JADX */
        public static final int actionModeCloseButtonStyle = 2130903059;
        /* added by JADX */
        public static final int actionModeCloseContentDescription = 2130903060;
        /* added by JADX */
        public static final int actionModeCloseDrawable = 2130903061;
        /* added by JADX */
        public static final int actionModeCopyDrawable = 2130903062;
        /* added by JADX */
        public static final int actionModeCutDrawable = 2130903063;
        /* added by JADX */
        public static final int actionModeFindDrawable = 2130903064;
        /* added by JADX */
        public static final int actionModePasteDrawable = 2130903065;
        /* added by JADX */
        public static final int actionModePopupWindowStyle = 2130903066;
        /* added by JADX */
        public static final int actionModeSelectAllDrawable = 2130903067;
        /* added by JADX */
        public static final int actionModeShareDrawable = 2130903068;
        /* added by JADX */
        public static final int actionModeSplitBackground = 2130903069;
        /* added by JADX */
        public static final int actionModeStyle = 2130903070;
        /* added by JADX */
        public static final int actionModeTheme = 2130903071;
        /* added by JADX */
        public static final int actionModeWebSearchDrawable = 2130903072;
        /* added by JADX */
        public static final int actionOverflowButtonStyle = 2130903073;
        /* added by JADX */
        public static final int actionOverflowMenuStyle = 2130903074;
        /* added by JADX */
        public static final int actionProviderClass = 2130903075;
        /* added by JADX */
        public static final int actionViewClass = 2130903076;
        /* added by JADX */
        public static final int activityChooserViewStyle = 2130903077;
        /* added by JADX */
        public static final int alertDialogButtonGroupStyle = 2130903078;
        /* added by JADX */
        public static final int alertDialogCenterButtons = 2130903079;
        /* added by JADX */
        public static final int alertDialogStyle = 2130903080;
        /* added by JADX */
        public static final int alertDialogTheme = 2130903081;
        /* added by JADX */
        public static final int allowStacking = 2130903082;
        /* added by JADX */
        public static final int alpha = 2130903083;
        /* added by JADX */
        public static final int alphabeticModifiers = 2130903084;
        /* added by JADX */
        public static final int altSrc = 2130903085;
        /* added by JADX */
        public static final int animateCircleAngleTo = 2130903086;
        /* added by JADX */
        public static final int animateRelativeTo = 2130903087;
        /* added by JADX */
        public static final int applyMotionScene = 2130903088;
        /* added by JADX */
        public static final int arcMode = 2130903089;
        /* added by JADX */
        public static final int arrowHeadLength = 2130903090;
        /* added by JADX */
        public static final int arrowShaftLength = 2130903091;
        /* added by JADX */
        public static final int attributeName = 2130903092;
        /* added by JADX */
        public static final int autoCompleteMode = 2130903093;
        /* added by JADX */
        public static final int autoCompleteTextViewStyle = 2130903094;
        /* added by JADX */
        public static final int autoSizeMaxTextSize = 2130903095;
        /* added by JADX */
        public static final int autoSizeMinTextSize = 2130903096;
        /* added by JADX */
        public static final int autoSizePresetSizes = 2130903097;
        /* added by JADX */
        public static final int autoSizeStepGranularity = 2130903098;
        /* added by JADX */
        public static final int autoSizeTextType = 2130903099;
        /* added by JADX */
        public static final int autoTransition = 2130903100;
        /* added by JADX */
        public static final int background = 2130903101;
        /* added by JADX */
        public static final int backgroundSplit = 2130903102;
        /* added by JADX */
        public static final int backgroundStacked = 2130903103;
        /* added by JADX */
        public static final int backgroundTint = 2130903104;
        /* added by JADX */
        public static final int backgroundTintMode = 2130903105;
        /* added by JADX */
        public static final int barLength = 2130903106;
        /* added by JADX */
        public static final int barrierAllowsGoneWidgets = 2130903107;
        /* added by JADX */
        public static final int barrierDirection = 2130903108;
        /* added by JADX */
        public static final int barrierMargin = 2130903109;
        /* added by JADX */
        public static final int blendSrc = 2130903110;
        /* added by JADX */
        public static final int borderRound = 2130903111;
        /* added by JADX */
        public static final int borderRoundPercent = 2130903112;
        /* added by JADX */
        public static final int borderlessButtonStyle = 2130903113;
        /* added by JADX */
        public static final int brightness = 2130903114;
        /* added by JADX */
        public static final int buttonBarButtonStyle = 2130903115;
        /* added by JADX */
        public static final int buttonBarNegativeButtonStyle = 2130903116;
        /* added by JADX */
        public static final int buttonBarNeutralButtonStyle = 2130903117;
        /* added by JADX */
        public static final int buttonBarPositiveButtonStyle = 2130903118;
        /* added by JADX */
        public static final int buttonBarStyle = 2130903119;
        /* added by JADX */
        public static final int buttonCompat = 2130903120;
        /* added by JADX */
        public static final int buttonGravity = 2130903121;
        /* added by JADX */
        public static final int buttonIconDimen = 2130903122;
        /* added by JADX */
        public static final int buttonPanelSideLayout = 2130903123;
        /* added by JADX */
        public static final int buttonStyle = 2130903124;
        /* added by JADX */
        public static final int buttonStyleSmall = 2130903125;
        /* added by JADX */
        public static final int buttonTint = 2130903126;
        /* added by JADX */
        public static final int buttonTintMode = 2130903127;
        /* added by JADX */
        public static final int carousel_backwardTransition = 2130903128;
        /* added by JADX */
        public static final int carousel_emptyViewsBehavior = 2130903129;
        /* added by JADX */
        public static final int carousel_firstView = 2130903130;
        /* added by JADX */
        public static final int carousel_forwardTransition = 2130903131;
        /* added by JADX */
        public static final int carousel_infinite = 2130903132;
        /* added by JADX */
        public static final int carousel_nextState = 2130903133;
        /* added by JADX */
        public static final int carousel_previousState = 2130903134;
        /* added by JADX */
        public static final int carousel_touchUpMode = 2130903135;
        /* added by JADX */
        public static final int carousel_touchUp_dampeningFactor = 2130903136;
        /* added by JADX */
        public static final int carousel_touchUp_velocityThreshold = 2130903137;
        /* added by JADX */
        public static final int chainUseRtl = 2130903138;
        /* added by JADX */
        public static final int checkMarkCompat = 2130903139;
        /* added by JADX */
        public static final int checkMarkTint = 2130903140;
        /* added by JADX */
        public static final int checkMarkTintMode = 2130903141;
        /* added by JADX */
        public static final int checkboxStyle = 2130903142;
        /* added by JADX */
        public static final int checkedTextViewStyle = 2130903143;
        /* added by JADX */
        public static final int circleRadius = 2130903144;
        /* added by JADX */
        public static final int circularflow_angles = 2130903145;
        /* added by JADX */
        public static final int circularflow_defaultAngle = 2130903146;
        /* added by JADX */
        public static final int circularflow_defaultRadius = 2130903147;
        /* added by JADX */
        public static final int circularflow_radiusInDP = 2130903148;
        /* added by JADX */
        public static final int circularflow_viewCenter = 2130903149;
        /* added by JADX */
        public static final int clearsTag = 2130903150;
        /* added by JADX */
        public static final int clickAction = 2130903151;
        /* added by JADX */
        public static final int closeIcon = 2130903152;
        /* added by JADX */
        public static final int closeItemLayout = 2130903153;
        /* added by JADX */
        public static final int collapseContentDescription = 2130903154;
        /* added by JADX */
        public static final int collapseIcon = 2130903155;
        /* added by JADX */
        public static final int color = 2130903156;
        /* added by JADX */
        public static final int colorAccent = 2130903157;
        /* added by JADX */
        public static final int colorBackgroundFloating = 2130903158;
        /* added by JADX */
        public static final int colorButtonNormal = 2130903159;
        /* added by JADX */
        public static final int colorControlActivated = 2130903160;
        /* added by JADX */
        public static final int colorControlHighlight = 2130903161;
        /* added by JADX */
        public static final int colorControlNormal = 2130903162;
        /* added by JADX */
        public static final int colorError = 2130903163;
        /* added by JADX */
        public static final int colorPrimary = 2130903164;
        /* added by JADX */
        public static final int colorPrimaryDark = 2130903165;
        /* added by JADX */
        public static final int colorSwitchThumbNormal = 2130903166;
        /* added by JADX */
        public static final int commitIcon = 2130903167;
        /* added by JADX */
        public static final int constraintRotate = 2130903168;
        /* added by JADX */
        public static final int constraintSet = 2130903169;
        /* added by JADX */
        public static final int constraintSetEnd = 2130903170;
        /* added by JADX */
        public static final int constraintSetStart = 2130903171;
        /* added by JADX */
        public static final int constraint_referenced_ids = 2130903172;
        /* added by JADX */
        public static final int constraint_referenced_tags = 2130903173;
        /* added by JADX */
        public static final int constraints = 2130903174;
        /* added by JADX */
        public static final int content = 2130903175;
        /* added by JADX */
        public static final int contentDescription = 2130903176;
        /* added by JADX */
        public static final int contentInsetEnd = 2130903177;
        /* added by JADX */
        public static final int contentInsetEndWithActions = 2130903178;
        /* added by JADX */
        public static final int contentInsetLeft = 2130903179;
        /* added by JADX */
        public static final int contentInsetRight = 2130903180;
        /* added by JADX */
        public static final int contentInsetStart = 2130903181;
        /* added by JADX */
        public static final int contentInsetStartWithNavigation = 2130903182;
        /* added by JADX */
        public static final int contrast = 2130903183;
        /* added by JADX */
        public static final int controlBackground = 2130903184;
        /* added by JADX */
        public static final int crossfade = 2130903185;
        /* added by JADX */
        public static final int currentState = 2130903186;
        /* added by JADX */
        public static final int curveFit = 2130903187;
        /* added by JADX */
        public static final int customBoolean = 2130903188;
        /* added by JADX */
        public static final int customColorDrawableValue = 2130903189;
        /* added by JADX */
        public static final int customColorValue = 2130903190;
        /* added by JADX */
        public static final int customDimension = 2130903191;
        /* added by JADX */
        public static final int customFloatValue = 2130903192;
        /* added by JADX */
        public static final int customIntegerValue = 2130903193;
        /* added by JADX */
        public static final int customNavigationLayout = 2130903194;
        /* added by JADX */
        public static final int customPixelDimension = 2130903195;
        /* added by JADX */
        public static final int customReference = 2130903196;
        /* added by JADX */
        public static final int customStringValue = 2130903197;
        /* added by JADX */
        public static final int defaultDuration = 2130903198;
        /* added by JADX */
        public static final int defaultQueryHint = 2130903199;
        /* added by JADX */
        public static final int defaultState = 2130903200;
        /* added by JADX */
        public static final int deltaPolarAngle = 2130903201;
        /* added by JADX */
        public static final int deltaPolarRadius = 2130903202;
        /* added by JADX */
        public static final int deriveConstraintsFrom = 2130903203;
        /* added by JADX */
        public static final int dialogCornerRadius = 2130903204;
        /* added by JADX */
        public static final int dialogPreferredPadding = 2130903205;
        /* added by JADX */
        public static final int dialogTheme = 2130903206;
        /* added by JADX */
        public static final int displayOptions = 2130903207;
        /* added by JADX */
        public static final int divider = 2130903208;
        /* added by JADX */
        public static final int dividerHorizontal = 2130903209;
        /* added by JADX */
        public static final int dividerPadding = 2130903210;
        /* added by JADX */
        public static final int dividerVertical = 2130903211;
        /* added by JADX */
        public static final int dragDirection = 2130903212;
        /* added by JADX */
        public static final int dragScale = 2130903213;
        /* added by JADX */
        public static final int dragThreshold = 2130903214;
        /* added by JADX */
        public static final int drawPath = 2130903215;
        /* added by JADX */
        public static final int drawableBottomCompat = 2130903216;
        /* added by JADX */
        public static final int drawableEndCompat = 2130903217;
        /* added by JADX */
        public static final int drawableLeftCompat = 2130903218;
        /* added by JADX */
        public static final int drawableRightCompat = 2130903219;
        /* added by JADX */
        public static final int drawableSize = 2130903220;
        /* added by JADX */
        public static final int drawableStartCompat = 2130903221;
        /* added by JADX */
        public static final int drawableTint = 2130903222;
        /* added by JADX */
        public static final int drawableTintMode = 2130903223;
        /* added by JADX */
        public static final int drawableTopCompat = 2130903224;
        /* added by JADX */
        public static final int drawerArrowStyle = 2130903225;
        /* added by JADX */
        public static final int dropDownListViewStyle = 2130903226;
        /* added by JADX */
        public static final int dropdownListPreferredItemHeight = 2130903227;
        /* added by JADX */
        public static final int duration = 2130903228;
        /* added by JADX */
        public static final int editTextBackground = 2130903229;
        /* added by JADX */
        public static final int editTextColor = 2130903230;
        /* added by JADX */
        public static final int editTextStyle = 2130903231;
        /* added by JADX */
        public static final int elevation = 2130903232;
        /* added by JADX */
        public static final int emojiCompatEnabled = 2130903233;
        /* added by JADX */
        public static final int expandActivityOverflowButtonDrawable = 2130903234;
        /* added by JADX */
        public static final int firstBaselineToTopHeight = 2130903235;
        /* added by JADX */
        public static final int flow_firstHorizontalBias = 2130903236;
        /* added by JADX */
        public static final int flow_firstHorizontalStyle = 2130903237;
        /* added by JADX */
        public static final int flow_firstVerticalBias = 2130903238;
        /* added by JADX */
        public static final int flow_firstVerticalStyle = 2130903239;
        /* added by JADX */
        public static final int flow_horizontalAlign = 2130903240;
        /* added by JADX */
        public static final int flow_horizontalBias = 2130903241;
        /* added by JADX */
        public static final int flow_horizontalGap = 2130903242;
        /* added by JADX */
        public static final int flow_horizontalStyle = 2130903243;
        /* added by JADX */
        public static final int flow_lastHorizontalBias = 2130903244;
        /* added by JADX */
        public static final int flow_lastHorizontalStyle = 2130903245;
        /* added by JADX */
        public static final int flow_lastVerticalBias = 2130903246;
        /* added by JADX */
        public static final int flow_lastVerticalStyle = 2130903247;
        /* added by JADX */
        public static final int flow_maxElementsWrap = 2130903248;
        /* added by JADX */
        public static final int flow_padding = 2130903249;
        /* added by JADX */
        public static final int flow_verticalAlign = 2130903250;
        /* added by JADX */
        public static final int flow_verticalBias = 2130903251;
        /* added by JADX */
        public static final int flow_verticalGap = 2130903252;
        /* added by JADX */
        public static final int flow_verticalStyle = 2130903253;
        /* added by JADX */
        public static final int flow_wrapMode = 2130903254;
        /* added by JADX */
        public static final int font = 2130903255;
        /* added by JADX */
        public static final int fontFamily = 2130903256;
        /* added by JADX */
        public static final int fontProviderAuthority = 2130903257;
        /* added by JADX */
        public static final int fontProviderCerts = 2130903258;
        /* added by JADX */
        public static final int fontProviderFetchStrategy = 2130903259;
        /* added by JADX */
        public static final int fontProviderFetchTimeout = 2130903260;
        /* added by JADX */
        public static final int fontProviderPackage = 2130903261;
        /* added by JADX */
        public static final int fontProviderQuery = 2130903262;
        /* added by JADX */
        public static final int fontProviderSystemFontFamily = 2130903263;
        /* added by JADX */
        public static final int fontStyle = 2130903264;
        /* added by JADX */
        public static final int fontVariationSettings = 2130903265;
        /* added by JADX */
        public static final int fontWeight = 2130903266;
        /* added by JADX */
        public static final int framePosition = 2130903267;
        /* added by JADX */
        public static final int gapBetweenBars = 2130903268;
        /* added by JADX */
        public static final int goIcon = 2130903269;
        /* added by JADX */
        public static final int guidelineUseRtl = 2130903270;
        /* added by JADX */
        public static final int height = 2130903271;
        /* added by JADX */
        public static final int hideOnContentScroll = 2130903272;
        /* added by JADX */
        public static final int homeAsUpIndicator = 2130903273;
        /* added by JADX */
        public static final int homeLayout = 2130903274;
        /* added by JADX */
        public static final int icon = 2130903275;
        /* added by JADX */
        public static final int iconTint = 2130903276;
        /* added by JADX */
        public static final int iconTintMode = 2130903277;
        /* added by JADX */
        public static final int iconifiedByDefault = 2130903278;
        /* added by JADX */
        public static final int ifTagNotSet = 2130903279;
        /* added by JADX */
        public static final int ifTagSet = 2130903280;
        /* added by JADX */
        public static final int imageButtonStyle = 2130903281;
        /* added by JADX */
        public static final int imagePanX = 2130903282;
        /* added by JADX */
        public static final int imagePanY = 2130903283;
        /* added by JADX */
        public static final int imageRotate = 2130903284;
        /* added by JADX */
        public static final int imageZoom = 2130903285;
        /* added by JADX */
        public static final int indeterminateProgressStyle = 2130903286;
        /* added by JADX */
        public static final int initialActivityCount = 2130903287;
        /* added by JADX */
        public static final int isLightTheme = 2130903288;
        /* added by JADX */
        public static final int itemPadding = 2130903289;
        /* added by JADX */
        public static final int keyPositionType = 2130903290;
        /* added by JADX */
        public static final int lStar = 2130903291;
        /* added by JADX */
        public static final int lastBaselineToBottomHeight = 2130903292;
        /* added by JADX */
        public static final int layout = 2130903293;
        /* added by JADX */
        public static final int layoutDescription = 2130903294;
        /* added by JADX */
        public static final int layoutDuringTransition = 2130903295;
        /* added by JADX */
        public static final int layout_constrainedHeight = 2130903296;
        /* added by JADX */
        public static final int layout_constrainedWidth = 2130903297;
        /* added by JADX */
        public static final int layout_constraintBaseline_creator = 2130903298;
        /* added by JADX */
        public static final int layout_constraintBaseline_toBaselineOf = 2130903299;
        /* added by JADX */
        public static final int layout_constraintBaseline_toBottomOf = 2130903300;
        /* added by JADX */
        public static final int layout_constraintBaseline_toTopOf = 2130903301;
        /* added by JADX */
        public static final int layout_constraintBottom_creator = 2130903302;
        /* added by JADX */
        public static final int layout_constraintBottom_toBottomOf = 2130903303;
        /* added by JADX */
        public static final int layout_constraintBottom_toTopOf = 2130903304;
        /* added by JADX */
        public static final int layout_constraintCircle = 2130903305;
        /* added by JADX */
        public static final int layout_constraintCircleAngle = 2130903306;
        /* added by JADX */
        public static final int layout_constraintCircleRadius = 2130903307;
        /* added by JADX */
        public static final int layout_constraintDimensionRatio = 2130903308;
        /* added by JADX */
        public static final int layout_constraintEnd_toEndOf = 2130903309;
        /* added by JADX */
        public static final int layout_constraintEnd_toStartOf = 2130903310;
        /* added by JADX */
        public static final int layout_constraintGuide_begin = 2130903311;
        /* added by JADX */
        public static final int layout_constraintGuide_end = 2130903312;
        /* added by JADX */
        public static final int layout_constraintGuide_percent = 2130903313;
        /* added by JADX */
        public static final int layout_constraintHeight = 2130903314;
        /* added by JADX */
        public static final int layout_constraintHeight_default = 2130903315;
        /* added by JADX */
        public static final int layout_constraintHeight_max = 2130903316;
        /* added by JADX */
        public static final int layout_constraintHeight_min = 2130903317;
        /* added by JADX */
        public static final int layout_constraintHeight_percent = 2130903318;
        /* added by JADX */
        public static final int layout_constraintHorizontal_bias = 2130903319;
        /* added by JADX */
        public static final int layout_constraintHorizontal_chainStyle = 2130903320;
        /* added by JADX */
        public static final int layout_constraintHorizontal_weight = 2130903321;
        /* added by JADX */
        public static final int layout_constraintLeft_creator = 2130903322;
        /* added by JADX */
        public static final int layout_constraintLeft_toLeftOf = 2130903323;
        /* added by JADX */
        public static final int layout_constraintLeft_toRightOf = 2130903324;
        /* added by JADX */
        public static final int layout_constraintRight_creator = 2130903325;
        /* added by JADX */
        public static final int layout_constraintRight_toLeftOf = 2130903326;
        /* added by JADX */
        public static final int layout_constraintRight_toRightOf = 2130903327;
        /* added by JADX */
        public static final int layout_constraintStart_toEndOf = 2130903328;
        /* added by JADX */
        public static final int layout_constraintStart_toStartOf = 2130903329;
        /* added by JADX */
        public static final int layout_constraintTag = 2130903330;
        /* added by JADX */
        public static final int layout_constraintTop_creator = 2130903331;
        /* added by JADX */
        public static final int layout_constraintTop_toBottomOf = 2130903332;
        /* added by JADX */
        public static final int layout_constraintTop_toTopOf = 2130903333;
        /* added by JADX */
        public static final int layout_constraintVertical_bias = 2130903334;
        /* added by JADX */
        public static final int layout_constraintVertical_chainStyle = 2130903335;
        /* added by JADX */
        public static final int layout_constraintVertical_weight = 2130903336;
        /* added by JADX */
        public static final int layout_constraintWidth = 2130903337;
        /* added by JADX */
        public static final int layout_constraintWidth_default = 2130903338;
        /* added by JADX */
        public static final int layout_constraintWidth_max = 2130903339;
        /* added by JADX */
        public static final int layout_constraintWidth_min = 2130903340;
        /* added by JADX */
        public static final int layout_constraintWidth_percent = 2130903341;
        /* added by JADX */
        public static final int layout_editor_absoluteX = 2130903342;
        /* added by JADX */
        public static final int layout_editor_absoluteY = 2130903343;
        /* added by JADX */
        public static final int layout_goneMarginBaseline = 2130903344;
        /* added by JADX */
        public static final int layout_goneMarginBottom = 2130903345;
        /* added by JADX */
        public static final int layout_goneMarginEnd = 2130903346;
        /* added by JADX */
        public static final int layout_goneMarginLeft = 2130903347;
        /* added by JADX */
        public static final int layout_goneMarginRight = 2130903348;
        /* added by JADX */
        public static final int layout_goneMarginStart = 2130903349;
        /* added by JADX */
        public static final int layout_goneMarginTop = 2130903350;
        /* added by JADX */
        public static final int layout_marginBaseline = 2130903351;
        /* added by JADX */
        public static final int layout_optimizationLevel = 2130903352;
        /* added by JADX */
        public static final int layout_wrapBehaviorInParent = 2130903353;
        /* added by JADX */
        public static final int limitBoundsTo = 2130903354;
        /* added by JADX */
        public static final int lineHeight = 2130903355;
        /* added by JADX */
        public static final int listChoiceBackgroundIndicator = 2130903356;
        /* added by JADX */
        public static final int listChoiceIndicatorMultipleAnimated = 2130903357;
        /* added by JADX */
        public static final int listChoiceIndicatorSingleAnimated = 2130903358;
        /* added by JADX */
        public static final int listDividerAlertDialog = 2130903359;
        /* added by JADX */
        public static final int listItemLayout = 2130903360;
        /* added by JADX */
        public static final int listLayout = 2130903361;
        /* added by JADX */
        public static final int listMenuViewStyle = 2130903362;
        /* added by JADX */
        public static final int listPopupWindowStyle = 2130903363;
        /* added by JADX */
        public static final int listPreferredItemHeight = 2130903364;
        /* added by JADX */
        public static final int listPreferredItemHeightLarge = 2130903365;
        /* added by JADX */
        public static final int listPreferredItemHeightSmall = 2130903366;
        /* added by JADX */
        public static final int listPreferredItemPaddingEnd = 2130903367;
        /* added by JADX */
        public static final int listPreferredItemPaddingLeft = 2130903368;
        /* added by JADX */
        public static final int listPreferredItemPaddingRight = 2130903369;
        /* added by JADX */
        public static final int listPreferredItemPaddingStart = 2130903370;
        /* added by JADX */
        public static final int logo = 2130903371;
        /* added by JADX */
        public static final int logoDescription = 2130903372;
        /* added by JADX */
        public static final int maxAcceleration = 2130903373;
        /* added by JADX */
        public static final int maxButtonHeight = 2130903374;
        /* added by JADX */
        public static final int maxHeight = 2130903375;
        /* added by JADX */
        public static final int maxVelocity = 2130903376;
        /* added by JADX */
        public static final int maxWidth = 2130903377;
        /* added by JADX */
        public static final int measureWithLargestChild = 2130903378;
        /* added by JADX */
        public static final int menu = 2130903379;
        /* added by JADX */
        public static final int methodName = 2130903380;
        /* added by JADX */
        public static final int minHeight = 2130903381;
        /* added by JADX */
        public static final int minWidth = 2130903382;
        /* added by JADX */
        public static final int mock_diagonalsColor = 2130903383;
        /* added by JADX */
        public static final int mock_label = 2130903384;
        /* added by JADX */
        public static final int mock_labelBackgroundColor = 2130903385;
        /* added by JADX */
        public static final int mock_labelColor = 2130903386;
        /* added by JADX */
        public static final int mock_showDiagonals = 2130903387;
        /* added by JADX */
        public static final int mock_showLabel = 2130903388;
        /* added by JADX */
        public static final int motionDebug = 2130903389;
        /* added by JADX */
        public static final int motionEffect_alpha = 2130903390;
        /* added by JADX */
        public static final int motionEffect_end = 2130903391;
        /* added by JADX */
        public static final int motionEffect_move = 2130903392;
        /* added by JADX */
        public static final int motionEffect_start = 2130903393;
        /* added by JADX */
        public static final int motionEffect_strict = 2130903394;
        /* added by JADX */
        public static final int motionEffect_translationX = 2130903395;
        /* added by JADX */
        public static final int motionEffect_translationY = 2130903396;
        /* added by JADX */
        public static final int motionEffect_viewTransition = 2130903397;
        /* added by JADX */
        public static final int motionInterpolator = 2130903398;
        /* added by JADX */
        public static final int motionPathRotate = 2130903399;
        /* added by JADX */
        public static final int motionProgress = 2130903400;
        /* added by JADX */
        public static final int motionStagger = 2130903401;
        /* added by JADX */
        public static final int motionTarget = 2130903402;
        /* added by JADX */
        public static final int motion_postLayoutCollision = 2130903403;
        /* added by JADX */
        public static final int motion_triggerOnCollision = 2130903404;
        /* added by JADX */
        public static final int moveWhenScrollAtTop = 2130903405;
        /* added by JADX */
        public static final int multiChoiceItemLayout = 2130903406;
        /* added by JADX */
        public static final int navigationContentDescription = 2130903407;
        /* added by JADX */
        public static final int navigationIcon = 2130903408;
        /* added by JADX */
        public static final int navigationMode = 2130903409;
        /* added by JADX */
        public static final int nestedScrollFlags = 2130903410;
        /* added by JADX */
        public static final int nestedScrollViewStyle = 2130903411;
        /* added by JADX */
        public static final int numericModifiers = 2130903412;
        /* added by JADX */
        public static final int onCross = 2130903413;
        /* added by JADX */
        public static final int onHide = 2130903414;
        /* added by JADX */
        public static final int onNegativeCross = 2130903415;
        /* added by JADX */
        public static final int onPositiveCross = 2130903416;
        /* added by JADX */
        public static final int onShow = 2130903417;
        /* added by JADX */
        public static final int onStateTransition = 2130903418;
        /* added by JADX */
        public static final int onTouchUp = 2130903419;
        /* added by JADX */
        public static final int overlapAnchor = 2130903420;
        /* added by JADX */
        public static final int overlay = 2130903421;
        /* added by JADX */
        public static final int paddingBottomNoButtons = 2130903422;
        /* added by JADX */
        public static final int paddingEnd = 2130903423;
        /* added by JADX */
        public static final int paddingStart = 2130903424;
        /* added by JADX */
        public static final int paddingTopNoTitle = 2130903425;
        /* added by JADX */
        public static final int panelBackground = 2130903426;
        /* added by JADX */
        public static final int panelMenuListTheme = 2130903427;
        /* added by JADX */
        public static final int panelMenuListWidth = 2130903428;
        /* added by JADX */
        public static final int pathMotionArc = 2130903429;
        /* added by JADX */
        public static final int path_percent = 2130903430;
        /* added by JADX */
        public static final int percentHeight = 2130903431;
        /* added by JADX */
        public static final int percentWidth = 2130903432;
        /* added by JADX */
        public static final int percentX = 2130903433;
        /* added by JADX */
        public static final int percentY = 2130903434;
        /* added by JADX */
        public static final int perpendicularPath_percent = 2130903435;
        /* added by JADX */
        public static final int pivotAnchor = 2130903436;
        /* added by JADX */
        public static final int placeholder_emptyVisibility = 2130903437;
        /* added by JADX */
        public static final int polarRelativeTo = 2130903438;
        /* added by JADX */
        public static final int popupMenuStyle = 2130903439;
        /* added by JADX */
        public static final int popupTheme = 2130903440;
        /* added by JADX */
        public static final int popupWindowStyle = 2130903441;
        /* added by JADX */
        public static final int preserveIconSpacing = 2130903442;
        /* added by JADX */
        public static final int progressBarPadding = 2130903443;
        /* added by JADX */
        public static final int progressBarStyle = 2130903444;
        /* added by JADX */
        public static final int quantizeMotionInterpolator = 2130903445;
        /* added by JADX */
        public static final int quantizeMotionPhase = 2130903446;
        /* added by JADX */
        public static final int quantizeMotionSteps = 2130903447;
        /* added by JADX */
        public static final int queryBackground = 2130903448;
        /* added by JADX */
        public static final int queryHint = 2130903449;
        /* added by JADX */
        public static final int queryPatterns = 2130903450;
        /* added by JADX */
        public static final int radioButtonStyle = 2130903451;
        /* added by JADX */
        public static final int ratingBarStyle = 2130903452;
        /* added by JADX */
        public static final int ratingBarStyleIndicator = 2130903453;
        /* added by JADX */
        public static final int ratingBarStyleSmall = 2130903454;
        /* added by JADX */
        public static final int reactiveGuide_animateChange = 2130903455;
        /* added by JADX */
        public static final int reactiveGuide_applyToAllConstraintSets = 2130903456;
        /* added by JADX */
        public static final int reactiveGuide_applyToConstraintSet = 2130903457;
        /* added by JADX */
        public static final int reactiveGuide_valueId = 2130903458;
        /* added by JADX */
        public static final int region_heightLessThan = 2130903459;
        /* added by JADX */
        public static final int region_heightMoreThan = 2130903460;
        /* added by JADX */
        public static final int region_widthLessThan = 2130903461;
        /* added by JADX */
        public static final int region_widthMoreThan = 2130903462;
        /* added by JADX */
        public static final int rotationCenterId = 2130903463;
        /* added by JADX */
        public static final int round = 2130903464;
        /* added by JADX */
        public static final int roundPercent = 2130903465;
        /* added by JADX */
        public static final int saturation = 2130903466;
        /* added by JADX */
        public static final int scaleFromTextSize = 2130903467;
        /* added by JADX */
        public static final int searchHintIcon = 2130903468;
        /* added by JADX */
        public static final int searchIcon = 2130903469;
        /* added by JADX */
        public static final int searchViewStyle = 2130903470;
        /* added by JADX */
        public static final int seekBarStyle = 2130903471;
        /* added by JADX */
        public static final int selectableItemBackground = 2130903472;
        /* added by JADX */
        public static final int selectableItemBackgroundBorderless = 2130903473;
        /* added by JADX */
        public static final int setsTag = 2130903474;
        /* added by JADX */
        public static final int shortcutMatchRequired = 2130903475;
        /* added by JADX */
        public static final int showAsAction = 2130903476;
        /* added by JADX */
        public static final int showDividers = 2130903477;
        /* added by JADX */
        public static final int showPaths = 2130903478;
        /* added by JADX */
        public static final int showText = 2130903479;
        /* added by JADX */
        public static final int showTitle = 2130903480;
        /* added by JADX */
        public static final int singleChoiceItemLayout = 2130903481;
        /* added by JADX */
        public static final int sizePercent = 2130903482;
        /* added by JADX */
        public static final int spinBars = 2130903483;
        /* added by JADX */
        public static final int spinnerDropDownItemStyle = 2130903484;
        /* added by JADX */
        public static final int spinnerStyle = 2130903485;
        /* added by JADX */
        public static final int splitTrack = 2130903486;
        /* added by JADX */
        public static final int springBoundary = 2130903487;
        /* added by JADX */
        public static final int springDamping = 2130903488;
        /* added by JADX */
        public static final int springMass = 2130903489;
        /* added by JADX */
        public static final int springStiffness = 2130903490;
        /* added by JADX */
        public static final int springStopThreshold = 2130903491;
        /* added by JADX */
        public static final int srcCompat = 2130903492;
        /* added by JADX */
        public static final int staggered = 2130903493;
        /* added by JADX */
        public static final int state_above_anchor = 2130903494;
        /* added by JADX */
        public static final int subMenuArrow = 2130903495;
        /* added by JADX */
        public static final int submitBackground = 2130903496;
        /* added by JADX */
        public static final int subtitle = 2130903497;
        /* added by JADX */
        public static final int subtitleTextAppearance = 2130903498;
        /* added by JADX */
        public static final int subtitleTextColor = 2130903499;
        /* added by JADX */
        public static final int subtitleTextStyle = 2130903500;
        /* added by JADX */
        public static final int suggestionRowLayout = 2130903501;
        /* added by JADX */
        public static final int switchMinWidth = 2130903502;
        /* added by JADX */
        public static final int switchPadding = 2130903503;
        /* added by JADX */
        public static final int switchStyle = 2130903504;
        /* added by JADX */
        public static final int switchTextAppearance = 2130903505;
        /* added by JADX */
        public static final int targetId = 2130903506;
        /* added by JADX */
        public static final int telltales_tailColor = 2130903507;
        /* added by JADX */
        public static final int telltales_tailScale = 2130903508;
        /* added by JADX */
        public static final int telltales_velocityMode = 2130903509;
        /* added by JADX */
        public static final int textAllCaps = 2130903510;
        /* added by JADX */
        public static final int textAppearanceLargePopupMenu = 2130903511;
        /* added by JADX */
        public static final int textAppearanceListItem = 2130903512;
        /* added by JADX */
        public static final int textAppearanceListItemSecondary = 2130903513;
        /* added by JADX */
        public static final int textAppearanceListItemSmall = 2130903514;
        /* added by JADX */
        public static final int textAppearancePopupMenuHeader = 2130903515;
        /* added by JADX */
        public static final int textAppearanceSearchResultSubtitle = 2130903516;
        /* added by JADX */
        public static final int textAppearanceSearchResultTitle = 2130903517;
        /* added by JADX */
        public static final int textAppearanceSmallPopupMenu = 2130903518;
        /* added by JADX */
        public static final int textBackground = 2130903519;
        /* added by JADX */
        public static final int textBackgroundPanX = 2130903520;
        /* added by JADX */
        public static final int textBackgroundPanY = 2130903521;
        /* added by JADX */
        public static final int textBackgroundRotate = 2130903522;
        /* added by JADX */
        public static final int textBackgroundZoom = 2130903523;
        /* added by JADX */
        public static final int textColorAlertDialogListItem = 2130903524;
        /* added by JADX */
        public static final int textColorSearchUrl = 2130903525;
        /* added by JADX */
        public static final int textFillColor = 2130903526;
        /* added by JADX */
        public static final int textLocale = 2130903527;
        /* added by JADX */
        public static final int textOutlineColor = 2130903528;
        /* added by JADX */
        public static final int textOutlineThickness = 2130903529;
        /* added by JADX */
        public static final int textPanX = 2130903530;
        /* added by JADX */
        public static final int textPanY = 2130903531;
        /* added by JADX */
        public static final int textureBlurFactor = 2130903532;
        /* added by JADX */
        public static final int textureEffect = 2130903533;
        /* added by JADX */
        public static final int textureHeight = 2130903534;
        /* added by JADX */
        public static final int textureWidth = 2130903535;
        /* added by JADX */
        public static final int theme = 2130903536;
        /* added by JADX */
        public static final int thickness = 2130903537;
        /* added by JADX */
        public static final int thumbTextPadding = 2130903538;
        /* added by JADX */
        public static final int thumbTint = 2130903539;
        /* added by JADX */
        public static final int thumbTintMode = 2130903540;
        /* added by JADX */
        public static final int tickMark = 2130903541;
        /* added by JADX */
        public static final int tickMarkTint = 2130903542;
        /* added by JADX */
        public static final int tickMarkTintMode = 2130903543;
        /* added by JADX */
        public static final int tint = 2130903544;
        /* added by JADX */
        public static final int tintMode = 2130903545;
        /* added by JADX */
        public static final int title = 2130903546;
        /* added by JADX */
        public static final int titleMargin = 2130903547;
        /* added by JADX */
        public static final int titleMarginBottom = 2130903548;
        /* added by JADX */
        public static final int titleMarginEnd = 2130903549;
        /* added by JADX */
        public static final int titleMarginStart = 2130903550;
        /* added by JADX */
        public static final int titleMarginTop = 2130903551;
        /* added by JADX */
        public static final int titleMargins = 2130903552;
        /* added by JADX */
        public static final int titleTextAppearance = 2130903553;
        /* added by JADX */
        public static final int titleTextColor = 2130903554;
        /* added by JADX */
        public static final int titleTextStyle = 2130903555;
        /* added by JADX */
        public static final int toolbarNavigationButtonStyle = 2130903556;
        /* added by JADX */
        public static final int toolbarStyle = 2130903557;
        /* added by JADX */
        public static final int tooltipForegroundColor = 2130903558;
        /* added by JADX */
        public static final int tooltipFrameBackground = 2130903559;
        /* added by JADX */
        public static final int tooltipText = 2130903560;
        /* added by JADX */
        public static final int touchAnchorId = 2130903561;
        /* added by JADX */
        public static final int touchAnchorSide = 2130903562;
        /* added by JADX */
        public static final int touchRegionId = 2130903563;
        /* added by JADX */
        public static final int track = 2130903564;
        /* added by JADX */
        public static final int trackTint = 2130903565;
        /* added by JADX */
        public static final int trackTintMode = 2130903566;
        /* added by JADX */
        public static final int transformPivotTarget = 2130903567;
        /* added by JADX */
        public static final int transitionDisable = 2130903568;
        /* added by JADX */
        public static final int transitionEasing = 2130903569;
        /* added by JADX */
        public static final int transitionFlags = 2130903570;
        /* added by JADX */
        public static final int transitionPathRotate = 2130903571;
        /* added by JADX */
        public static final int triggerId = 2130903572;
        /* added by JADX */
        public static final int triggerReceiver = 2130903573;
        /* added by JADX */
        public static final int triggerSlack = 2130903574;
        /* added by JADX */
        public static final int ttcIndex = 2130903575;
        /* added by JADX */
        public static final int upDuration = 2130903576;
        /* added by JADX */
        public static final int viewInflaterClass = 2130903577;
        /* added by JADX */
        public static final int viewTransitionMode = 2130903578;
        /* added by JADX */
        public static final int viewTransitionOnCross = 2130903579;
        /* added by JADX */
        public static final int viewTransitionOnNegativeCross = 2130903580;
        /* added by JADX */
        public static final int viewTransitionOnPositiveCross = 2130903581;
        /* added by JADX */
        public static final int visibilityMode = 2130903582;
        /* added by JADX */
        public static final int voiceIcon = 2130903583;
        /* added by JADX */
        public static final int warmth = 2130903584;
        /* added by JADX */
        public static final int waveDecay = 2130903585;
        /* added by JADX */
        public static final int waveOffset = 2130903586;
        /* added by JADX */
        public static final int wavePeriod = 2130903587;
        /* added by JADX */
        public static final int wavePhase = 2130903588;
        /* added by JADX */
        public static final int waveShape = 2130903589;
        /* added by JADX */
        public static final int waveVariesBy = 2130903590;
        /* added by JADX */
        public static final int windowActionBar = 2130903591;
        /* added by JADX */
        public static final int windowActionBarOverlay = 2130903592;
        /* added by JADX */
        public static final int windowActionModeOverlay = 2130903593;
        /* added by JADX */
        public static final int windowFixedHeightMajor = 2130903594;
        /* added by JADX */
        public static final int windowFixedHeightMinor = 2130903595;
        /* added by JADX */
        public static final int windowFixedWidthMajor = 2130903596;
        /* added by JADX */
        public static final int windowFixedWidthMinor = 2130903597;
        /* added by JADX */
        public static final int windowMinWidthMajor = 2130903598;
        /* added by JADX */
        public static final int windowMinWidthMinor = 2130903599;
        /* added by JADX */
        public static final int windowNoTitle = 2130903600;
    }

    /* added by JADX */
    public static final class bool {
        /* added by JADX */
        public static final int abc_action_bar_embed_tabs = 2130968576;
        /* added by JADX */
        public static final int abc_config_actionMenuItemAllCaps = 2130968577;
    }

    /* added by JADX */
    public static final class color {
        /* added by JADX */
        public static final int abc_background_cache_hint_selector_material_dark = 2131034112;
        /* added by JADX */
        public static final int abc_background_cache_hint_selector_material_light = 2131034113;
        /* added by JADX */
        public static final int abc_btn_colored_borderless_text_material = 2131034114;
        /* added by JADX */
        public static final int abc_btn_colored_text_material = 2131034115;
        /* added by JADX */
        public static final int abc_color_highlight_material = 2131034116;
        /* added by JADX */
        public static final int abc_decor_view_status_guard = 2131034117;
        /* added by JADX */
        public static final int abc_decor_view_status_guard_light = 2131034118;
        /* added by JADX */
        public static final int abc_hint_foreground_material_dark = 2131034119;
        /* added by JADX */
        public static final int abc_hint_foreground_material_light = 2131034120;
        /* added by JADX */
        public static final int abc_primary_text_disable_only_material_dark = 2131034121;
        /* added by JADX */
        public static final int abc_primary_text_disable_only_material_light = 2131034122;
        /* added by JADX */
        public static final int abc_primary_text_material_dark = 2131034123;
        /* added by JADX */
        public static final int abc_primary_text_material_light = 2131034124;
        /* added by JADX */
        public static final int abc_search_url_text = 2131034125;
        /* added by JADX */
        public static final int abc_search_url_text_normal = 2131034126;
        /* added by JADX */
        public static final int abc_search_url_text_pressed = 2131034127;
        /* added by JADX */
        public static final int abc_search_url_text_selected = 2131034128;
        /* added by JADX */
        public static final int abc_secondary_text_material_dark = 2131034129;
        /* added by JADX */
        public static final int abc_secondary_text_material_light = 2131034130;
        /* added by JADX */
        public static final int abc_tint_btn_checkable = 2131034131;
        /* added by JADX */
        public static final int abc_tint_default = 2131034132;
        /* added by JADX */
        public static final int abc_tint_edittext = 2131034133;
        /* added by JADX */
        public static final int abc_tint_seek_thumb = 2131034134;
        /* added by JADX */
        public static final int abc_tint_spinner = 2131034135;
        /* added by JADX */
        public static final int abc_tint_switch_track = 2131034136;
        /* added by JADX */
        public static final int accent_material_dark = 2131034137;
        /* added by JADX */
        public static final int accent_material_light = 2131034138;
        /* added by JADX */
        public static final int androidx_core_ripple_material_light = 2131034139;
        /* added by JADX */
        public static final int androidx_core_secondary_text_default_material_light = 2131034140;
        /* added by JADX */
        public static final int background_floating_material_dark = 2131034141;
        /* added by JADX */
        public static final int background_floating_material_light = 2131034142;
        /* added by JADX */
        public static final int background_material_dark = 2131034143;
        /* added by JADX */
        public static final int background_material_light = 2131034144;
        /* added by JADX */
        public static final int bright_foreground_disabled_material_dark = 2131034145;
        /* added by JADX */
        public static final int bright_foreground_disabled_material_light = 2131034146;
        /* added by JADX */
        public static final int bright_foreground_inverse_material_dark = 2131034147;
        /* added by JADX */
        public static final int bright_foreground_inverse_material_light = 2131034148;
        /* added by JADX */
        public static final int bright_foreground_material_dark = 2131034149;
        /* added by JADX */
        public static final int bright_foreground_material_light = 2131034150;
        /* added by JADX */
        public static final int button_material_dark = 2131034151;
        /* added by JADX */
        public static final int button_material_light = 2131034152;
        /* added by JADX */
        public static final int dim_foreground_disabled_material_dark = 2131034153;
        /* added by JADX */
        public static final int dim_foreground_disabled_material_light = 2131034154;
        /* added by JADX */
        public static final int dim_foreground_material_dark = 2131034155;
        /* added by JADX */
        public static final int dim_foreground_material_light = 2131034156;
        /* added by JADX */
        public static final int error_color_material_dark = 2131034157;
        /* added by JADX */
        public static final int error_color_material_light = 2131034158;
        /* added by JADX */
        public static final int foreground_material_dark = 2131034159;
        /* added by JADX */
        public static final int foreground_material_light = 2131034160;
        /* added by JADX */
        public static final int highlighted_text_material_dark = 2131034161;
        /* added by JADX */
        public static final int highlighted_text_material_light = 2131034162;
        /* added by JADX */
        public static final int material_blue_grey_800 = 2131034163;
        /* added by JADX */
        public static final int material_blue_grey_900 = 2131034164;
        /* added by JADX */
        public static final int material_blue_grey_950 = 2131034165;
        /* added by JADX */
        public static final int material_deep_teal_200 = 2131034166;
        /* added by JADX */
        public static final int material_deep_teal_500 = 2131034167;
        /* added by JADX */
        public static final int material_grey_100 = 2131034168;
        /* added by JADX */
        public static final int material_grey_300 = 2131034169;
        /* added by JADX */
        public static final int material_grey_50 = 2131034170;
        /* added by JADX */
        public static final int material_grey_600 = 2131034171;
        /* added by JADX */
        public static final int material_grey_800 = 2131034172;
        /* added by JADX */
        public static final int material_grey_850 = 2131034173;
        /* added by JADX */
        public static final int material_grey_900 = 2131034174;
        /* added by JADX */
        public static final int notification_action_color_filter = 2131034175;
        /* added by JADX */
        public static final int notification_icon_bg_color = 2131034176;
        /* added by JADX */
        public static final int primary_dark_material_dark = 2131034177;
        /* added by JADX */
        public static final int primary_dark_material_light = 2131034178;
        /* added by JADX */
        public static final int primary_material_dark = 2131034179;
        /* added by JADX */
        public static final int primary_material_light = 2131034180;
        /* added by JADX */
        public static final int primary_text_default_material_dark = 2131034181;
        /* added by JADX */
        public static final int primary_text_default_material_light = 2131034182;
        /* added by JADX */
        public static final int primary_text_disabled_material_dark = 2131034183;
        /* added by JADX */
        public static final int primary_text_disabled_material_light = 2131034184;
        /* added by JADX */
        public static final int ripple_material_dark = 2131034185;
        /* added by JADX */
        public static final int ripple_material_light = 2131034186;
        /* added by JADX */
        public static final int secondary_text_default_material_dark = 2131034187;
        /* added by JADX */
        public static final int secondary_text_default_material_light = 2131034188;
        /* added by JADX */
        public static final int secondary_text_disabled_material_dark = 2131034189;
        /* added by JADX */
        public static final int secondary_text_disabled_material_light = 2131034190;
        /* added by JADX */
        public static final int staticSplashScreenBackgroundColor = 2131034191;
        /* added by JADX */
        public static final int switch_thumb_disabled_material_dark = 2131034192;
        /* added by JADX */
        public static final int switch_thumb_disabled_material_light = 2131034193;
        /* added by JADX */
        public static final int switch_thumb_material_dark = 2131034194;
        /* added by JADX */
        public static final int switch_thumb_material_light = 2131034195;
        /* added by JADX */
        public static final int switch_thumb_normal_material_dark = 2131034196;
        /* added by JADX */
        public static final int switch_thumb_normal_material_light = 2131034197;
        /* added by JADX */
        public static final int tooltip_background_dark = 2131034198;
        /* added by JADX */
        public static final int tooltip_background_light = 2131034199;
    }

    /* added by JADX */
    public static final class dimen {
        /* added by JADX */
        public static final int abc_action_bar_content_inset_material = 2131099648;
        /* added by JADX */
        public static final int abc_action_bar_content_inset_with_nav = 2131099649;
        /* added by JADX */
        public static final int abc_action_bar_default_height_material = 2131099650;
        /* added by JADX */
        public static final int abc_action_bar_default_padding_end_material = 2131099651;
        /* added by JADX */
        public static final int abc_action_bar_default_padding_start_material = 2131099652;
        /* added by JADX */
        public static final int abc_action_bar_elevation_material = 2131099653;
        /* added by JADX */
        public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;
        /* added by JADX */
        public static final int abc_action_bar_overflow_padding_end_material = 2131099655;
        /* added by JADX */
        public static final int abc_action_bar_overflow_padding_start_material = 2131099656;
        /* added by JADX */
        public static final int abc_action_bar_stacked_max_height = 2131099657;
        /* added by JADX */
        public static final int abc_action_bar_stacked_tab_max_width = 2131099658;
        /* added by JADX */
        public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;
        /* added by JADX */
        public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;
        /* added by JADX */
        public static final int abc_action_button_min_height_material = 2131099661;
        /* added by JADX */
        public static final int abc_action_button_min_width_material = 2131099662;
        /* added by JADX */
        public static final int abc_action_button_min_width_overflow_material = 2131099663;
        /* added by JADX */
        public static final int abc_alert_dialog_button_bar_height = 2131099664;
        /* added by JADX */
        public static final int abc_alert_dialog_button_dimen = 2131099665;
        /* added by JADX */
        public static final int abc_button_inset_horizontal_material = 2131099666;
        /* added by JADX */
        public static final int abc_button_inset_vertical_material = 2131099667;
        /* added by JADX */
        public static final int abc_button_padding_horizontal_material = 2131099668;
        /* added by JADX */
        public static final int abc_button_padding_vertical_material = 2131099669;
        /* added by JADX */
        public static final int abc_cascading_menus_min_smallest_width = 2131099670;
        /* added by JADX */
        public static final int abc_config_prefDialogWidth = 2131099671;
        /* added by JADX */
        public static final int abc_control_corner_material = 2131099672;
        /* added by JADX */
        public static final int abc_control_inset_material = 2131099673;
        /* added by JADX */
        public static final int abc_control_padding_material = 2131099674;
        /* added by JADX */
        public static final int abc_dialog_corner_radius_material = 2131099675;
        /* added by JADX */
        public static final int abc_dialog_fixed_height_major = 2131099676;
        /* added by JADX */
        public static final int abc_dialog_fixed_height_minor = 2131099677;
        /* added by JADX */
        public static final int abc_dialog_fixed_width_major = 2131099678;
        /* added by JADX */
        public static final int abc_dialog_fixed_width_minor = 2131099679;
        /* added by JADX */
        public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;
        /* added by JADX */
        public static final int abc_dialog_list_padding_top_no_title = 2131099681;
        /* added by JADX */
        public static final int abc_dialog_min_width_major = 2131099682;
        /* added by JADX */
        public static final int abc_dialog_min_width_minor = 2131099683;
        /* added by JADX */
        public static final int abc_dialog_padding_material = 2131099684;
        /* added by JADX */
        public static final int abc_dialog_padding_top_material = 2131099685;
        /* added by JADX */
        public static final int abc_dialog_title_divider_material = 2131099686;
        /* added by JADX */
        public static final int abc_disabled_alpha_material_dark = 2131099687;
        /* added by JADX */
        public static final int abc_disabled_alpha_material_light = 2131099688;
        /* added by JADX */
        public static final int abc_dropdownitem_icon_width = 2131099689;
        /* added by JADX */
        public static final int abc_dropdownitem_text_padding_left = 2131099690;
        /* added by JADX */
        public static final int abc_dropdownitem_text_padding_right = 2131099691;
        /* added by JADX */
        public static final int abc_edit_text_inset_bottom_material = 2131099692;
        /* added by JADX */
        public static final int abc_edit_text_inset_horizontal_material = 2131099693;
        /* added by JADX */
        public static final int abc_edit_text_inset_top_material = 2131099694;
        /* added by JADX */
        public static final int abc_floating_window_z = 2131099695;
        /* added by JADX */
        public static final int abc_list_item_height_large_material = 2131099696;
        /* added by JADX */
        public static final int abc_list_item_height_material = 2131099697;
        /* added by JADX */
        public static final int abc_list_item_height_small_material = 2131099698;
        /* added by JADX */
        public static final int abc_list_item_padding_horizontal_material = 2131099699;
        /* added by JADX */
        public static final int abc_panel_menu_list_width = 2131099700;
        /* added by JADX */
        public static final int abc_progress_bar_height_material = 2131099701;
        /* added by JADX */
        public static final int abc_search_view_preferred_height = 2131099702;
        /* added by JADX */
        public static final int abc_search_view_preferred_width = 2131099703;
        /* added by JADX */
        public static final int abc_seekbar_track_background_height_material = 2131099704;
        /* added by JADX */
        public static final int abc_seekbar_track_progress_height_material = 2131099705;
        /* added by JADX */
        public static final int abc_select_dialog_padding_start_material = 2131099706;
        /* added by JADX */
        public static final int abc_star_big = 2131099707;
        /* added by JADX */
        public static final int abc_star_medium = 2131099708;
        /* added by JADX */
        public static final int abc_star_small = 2131099709;
        /* added by JADX */
        public static final int abc_switch_padding = 2131099710;
        /* added by JADX */
        public static final int abc_text_size_body_1_material = 2131099711;
        /* added by JADX */
        public static final int abc_text_size_body_2_material = 2131099712;
        /* added by JADX */
        public static final int abc_text_size_button_material = 2131099713;
        /* added by JADX */
        public static final int abc_text_size_caption_material = 2131099714;
        /* added by JADX */
        public static final int abc_text_size_display_1_material = 2131099715;
        /* added by JADX */
        public static final int abc_text_size_display_2_material = 2131099716;
        /* added by JADX */
        public static final int abc_text_size_display_3_material = 2131099717;
        /* added by JADX */
        public static final int abc_text_size_display_4_material = 2131099718;
        /* added by JADX */
        public static final int abc_text_size_headline_material = 2131099719;
        /* added by JADX */
        public static final int abc_text_size_large_material = 2131099720;
        /* added by JADX */
        public static final int abc_text_size_medium_material = 2131099721;
        /* added by JADX */
        public static final int abc_text_size_menu_header_material = 2131099722;
        /* added by JADX */
        public static final int abc_text_size_menu_material = 2131099723;
        /* added by JADX */
        public static final int abc_text_size_small_material = 2131099724;
        /* added by JADX */
        public static final int abc_text_size_subhead_material = 2131099725;
        /* added by JADX */
        public static final int abc_text_size_subtitle_material_toolbar = 2131099726;
        /* added by JADX */
        public static final int abc_text_size_title_material = 2131099727;
        /* added by JADX */
        public static final int abc_text_size_title_material_toolbar = 2131099728;
        /* added by JADX */
        public static final int compat_button_inset_horizontal_material = 2131099729;
        /* added by JADX */
        public static final int compat_button_inset_vertical_material = 2131099730;
        /* added by JADX */
        public static final int compat_button_padding_horizontal_material = 2131099731;
        /* added by JADX */
        public static final int compat_button_padding_vertical_material = 2131099732;
        /* added by JADX */
        public static final int compat_control_corner_material = 2131099733;
        /* added by JADX */
        public static final int compat_notification_large_icon_max_height = 2131099734;
        /* added by JADX */
        public static final int compat_notification_large_icon_max_width = 2131099735;
        /* added by JADX */
        public static final int disabled_alpha_material_dark = 2131099736;
        /* added by JADX */
        public static final int disabled_alpha_material_light = 2131099737;
        /* added by JADX */
        public static final int highlight_alpha_material_colored = 2131099738;
        /* added by JADX */
        public static final int highlight_alpha_material_dark = 2131099739;
        /* added by JADX */
        public static final int highlight_alpha_material_light = 2131099740;
        /* added by JADX */
        public static final int hint_alpha_material_dark = 2131099741;
        /* added by JADX */
        public static final int hint_alpha_material_light = 2131099742;
        /* added by JADX */
        public static final int hint_pressed_alpha_material_dark = 2131099743;
        /* added by JADX */
        public static final int hint_pressed_alpha_material_light = 2131099744;
        /* added by JADX */
        public static final int notification_action_icon_size = 2131099745;
        /* added by JADX */
        public static final int notification_action_text_size = 2131099746;
        /* added by JADX */
        public static final int notification_big_circle_margin = 2131099747;
        /* added by JADX */
        public static final int notification_content_margin_start = 2131099748;
        /* added by JADX */
        public static final int notification_large_icon_height = 2131099749;
        /* added by JADX */
        public static final int notification_large_icon_width = 2131099750;
        /* added by JADX */
        public static final int notification_main_column_padding_top = 2131099751;
        /* added by JADX */
        public static final int notification_media_narrow_margin = 2131099752;
        /* added by JADX */
        public static final int notification_right_icon_size = 2131099753;
        /* added by JADX */
        public static final int notification_right_side_padding_top = 2131099754;
        /* added by JADX */
        public static final int notification_small_icon_background_padding = 2131099755;
        /* added by JADX */
        public static final int notification_small_icon_size_as_large = 2131099756;
        /* added by JADX */
        public static final int notification_subtext_size = 2131099757;
        /* added by JADX */
        public static final int notification_top_pad = 2131099758;
        /* added by JADX */
        public static final int notification_top_pad_large_text = 2131099759;
        /* added by JADX */
        public static final int tooltip_corner_radius = 2131099760;
        /* added by JADX */
        public static final int tooltip_horizontal_padding = 2131099761;
        /* added by JADX */
        public static final int tooltip_margin = 2131099762;
        /* added by JADX */
        public static final int tooltip_precise_anchor_extra_offset = 2131099763;
        /* added by JADX */
        public static final int tooltip_precise_anchor_threshold = 2131099764;
        /* added by JADX */
        public static final int tooltip_vertical_padding = 2131099765;
        /* added by JADX */
        public static final int tooltip_y_offset_non_touch = 2131099766;
        /* added by JADX */
        public static final int tooltip_y_offset_touch = 2131099767;
    }

    /* added by JADX */
    public static final class drawable {
        /* added by JADX */
        public static final int abc_ab_share_pack_mtrl_alpha = 2131165184;
        /* added by JADX */
        public static final int abc_action_bar_item_background_material = 2131165185;
        /* added by JADX */
        public static final int abc_btn_borderless_material = 2131165186;
        /* added by JADX */
        public static final int abc_btn_check_material = 2131165187;
        /* added by JADX */
        public static final int abc_btn_check_material_anim = 2131165188;
        /* added by JADX */
        public static final int abc_btn_check_to_on_mtrl_000 = 2131165189;
        /* added by JADX */
        public static final int abc_btn_check_to_on_mtrl_015 = 2131165190;
        /* added by JADX */
        public static final int abc_btn_colored_material = 2131165191;
        /* added by JADX */
        public static final int abc_btn_default_mtrl_shape = 2131165192;
        /* added by JADX */
        public static final int abc_btn_radio_material = 2131165193;
        /* added by JADX */
        public static final int abc_btn_radio_material_anim = 2131165194;
        /* added by JADX */
        public static final int abc_btn_radio_to_on_mtrl_000 = 2131165195;
        /* added by JADX */
        public static final int abc_btn_radio_to_on_mtrl_015 = 2131165196;
        /* added by JADX */
        public static final int abc_btn_switch_to_on_mtrl_00001 = 2131165197;
        /* added by JADX */
        public static final int abc_btn_switch_to_on_mtrl_00012 = 2131165198;
        /* added by JADX */
        public static final int abc_cab_background_internal_bg = 2131165199;
        /* added by JADX */
        public static final int abc_cab_background_top_material = 2131165200;
        /* added by JADX */
        public static final int abc_cab_background_top_mtrl_alpha = 2131165201;
        /* added by JADX */
        public static final int abc_control_background_material = 2131165202;
        /* added by JADX */
        public static final int abc_dialog_material_background = 2131165203;
        /* added by JADX */
        public static final int abc_edit_text_material = 2131165204;
        /* added by JADX */
        public static final int abc_ic_ab_back_material = 2131165205;
        /* added by JADX */
        public static final int abc_ic_arrow_drop_right_black_24dp = 2131165206;
        /* added by JADX */
        public static final int abc_ic_clear_material = 2131165207;
        /* added by JADX */
        public static final int abc_ic_commit_search_api_mtrl_alpha = 2131165208;
        /* added by JADX */
        public static final int abc_ic_go_search_api_material = 2131165209;
        /* added by JADX */
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165210;
        /* added by JADX */
        public static final int abc_ic_menu_cut_mtrl_alpha = 2131165211;
        /* added by JADX */
        public static final int abc_ic_menu_overflow_material = 2131165212;
        /* added by JADX */
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165213;
        /* added by JADX */
        public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165214;
        /* added by JADX */
        public static final int abc_ic_menu_share_mtrl_alpha = 2131165215;
        /* added by JADX */
        public static final int abc_ic_search_api_material = 2131165216;
        /* added by JADX */
        public static final int abc_ic_voice_search_api_material = 2131165217;
        /* added by JADX */
        public static final int abc_item_background_holo_dark = 2131165218;
        /* added by JADX */
        public static final int abc_item_background_holo_light = 2131165219;
        /* added by JADX */
        public static final int abc_list_divider_material = 2131165220;
        /* added by JADX */
        public static final int abc_list_divider_mtrl_alpha = 2131165221;
        /* added by JADX */
        public static final int abc_list_focused_holo = 2131165222;
        /* added by JADX */
        public static final int abc_list_longpressed_holo = 2131165223;
        /* added by JADX */
        public static final int abc_list_pressed_holo_dark = 2131165224;
        /* added by JADX */
        public static final int abc_list_pressed_holo_light = 2131165225;
        /* added by JADX */
        public static final int abc_list_selector_background_transition_holo_dark = 2131165226;
        /* added by JADX */
        public static final int abc_list_selector_background_transition_holo_light = 2131165227;
        /* added by JADX */
        public static final int abc_list_selector_disabled_holo_dark = 2131165228;
        /* added by JADX */
        public static final int abc_list_selector_disabled_holo_light = 2131165229;
        /* added by JADX */
        public static final int abc_list_selector_holo_dark = 2131165230;
        /* added by JADX */
        public static final int abc_list_selector_holo_light = 2131165231;
        /* added by JADX */
        public static final int abc_menu_hardkey_panel_mtrl_mult = 2131165232;
        /* added by JADX */
        public static final int abc_popup_background_mtrl_mult = 2131165233;
        /* added by JADX */
        public static final int abc_ratingbar_indicator_material = 2131165234;
        /* added by JADX */
        public static final int abc_ratingbar_material = 2131165235;
        /* added by JADX */
        public static final int abc_ratingbar_small_material = 2131165236;
        /* added by JADX */
        public static final int abc_scrubber_control_off_mtrl_alpha = 2131165237;
        /* added by JADX */
        public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131165238;
        /* added by JADX */
        public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131165239;
        /* added by JADX */
        public static final int abc_scrubber_primary_mtrl_alpha = 2131165240;
        /* added by JADX */
        public static final int abc_scrubber_track_mtrl_alpha = 2131165241;
        /* added by JADX */
        public static final int abc_seekbar_thumb_material = 2131165242;
        /* added by JADX */
        public static final int abc_seekbar_tick_mark_material = 2131165243;
        /* added by JADX */
        public static final int abc_seekbar_track_material = 2131165244;
        /* added by JADX */
        public static final int abc_spinner_mtrl_am_alpha = 2131165245;
        /* added by JADX */
        public static final int abc_spinner_textfield_background_material = 2131165246;
        /* added by JADX */
        public static final int abc_star_black_48dp = 2131165247;
        /* added by JADX */
        public static final int abc_star_half_black_48dp = 2131165248;
        /* added by JADX */
        public static final int abc_switch_thumb_material = 2131165249;
        /* added by JADX */
        public static final int abc_switch_track_mtrl_alpha = 2131165250;
        /* added by JADX */
        public static final int abc_tab_indicator_material = 2131165251;
        /* added by JADX */
        public static final int abc_tab_indicator_mtrl_alpha = 2131165252;
        /* added by JADX */
        public static final int abc_text_cursor_material = 2131165253;
        /* added by JADX */
        public static final int abc_text_select_handle_left_mtrl = 2131165254;
        /* added by JADX */
        public static final int abc_text_select_handle_middle_mtrl = 2131165255;
        /* added by JADX */
        public static final int abc_text_select_handle_right_mtrl = 2131165256;
        /* added by JADX */
        public static final int abc_textfield_activated_mtrl_alpha = 2131165257;
        /* added by JADX */
        public static final int abc_textfield_default_mtrl_alpha = 2131165258;
        /* added by JADX */
        public static final int abc_textfield_search_activated_mtrl_alpha = 2131165259;
        /* added by JADX */
        public static final int abc_textfield_search_default_mtrl_alpha = 2131165260;
        /* added by JADX */
        public static final int abc_textfield_search_material = 2131165261;
        /* added by JADX */
        public static final int abc_vector_test = 2131165262;
        /* added by JADX */
        public static final int btn_checkbox_checked_mtrl = 2131165263;
        /* added by JADX */
        public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131165264;
        /* added by JADX */
        public static final int btn_checkbox_unchecked_mtrl = 2131165265;
        /* added by JADX */
        public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131165266;
        /* added by JADX */
        public static final int btn_radio_off_mtrl = 2131165267;
        /* added by JADX */
        public static final int btn_radio_off_to_on_mtrl_animation = 2131165268;
        /* added by JADX */
        public static final int btn_radio_on_mtrl = 2131165269;
        /* added by JADX */
        public static final int btn_radio_on_to_off_mtrl_animation = 2131165270;
        /* added by JADX */
        public static final int notification_action_background = 2131165271;
        /* added by JADX */
        public static final int notification_bg = 2131165272;
        /* added by JADX */
        public static final int notification_bg_low = 2131165273;
        /* added by JADX */
        public static final int notification_bg_low_normal = 2131165274;
        /* added by JADX */
        public static final int notification_bg_low_pressed = 2131165275;
        /* added by JADX */
        public static final int notification_bg_normal = 2131165276;
        /* added by JADX */
        public static final int notification_bg_normal_pressed = 2131165277;
        /* added by JADX */
        public static final int notification_icon_background = 2131165278;
        /* added by JADX */
        public static final int notification_template_icon_bg = 2131165279;
        /* added by JADX */
        public static final int notification_template_icon_low_bg = 2131165280;
        /* added by JADX */
        public static final int notification_tile_bg = 2131165281;
        /* added by JADX */
        public static final int notify_panel_notification_icon_bg = 2131165282;
        /* added by JADX */
        public static final int test_level_drawable = 2131165283;
        /* added by JADX */
        public static final int tooltip_frame_dark = 2131165284;
        /* added by JADX */
        public static final int tooltip_frame_light = 2131165285;
    }

    /* added by JADX */
    public static final class id {
        /* added by JADX */
        public static final int ALT = 2131230720;
        /* added by JADX */
        public static final int CTRL = 2131230721;
        /* added by JADX */
        public static final int FUNCTION = 2131230722;
        /* added by JADX */
        public static final int META = 2131230723;
        /* added by JADX */
        public static final int NO_DEBUG = 2131230724;
        /* added by JADX */
        public static final int SHIFT = 2131230725;
        /* added by JADX */
        public static final int SHOW_ALL = 2131230726;
        /* added by JADX */
        public static final int SHOW_PATH = 2131230727;
        /* added by JADX */
        public static final int SHOW_PROGRESS = 2131230728;
        /* added by JADX */
        public static final int SYM = 2131230729;
        /* added by JADX */
        public static final int accelerate = 2131230730;
        /* added by JADX */
        public static final int accessibility_action_clickable_span = 2131230731;
        /* added by JADX */
        public static final int accessibility_custom_action_0 = 2131230732;
        /* added by JADX */
        public static final int accessibility_custom_action_1 = 2131230733;
        /* added by JADX */
        public static final int accessibility_custom_action_10 = 2131230734;
        /* added by JADX */
        public static final int accessibility_custom_action_11 = 2131230735;
        /* added by JADX */
        public static final int accessibility_custom_action_12 = 2131230736;
        /* added by JADX */
        public static final int accessibility_custom_action_13 = 2131230737;
        /* added by JADX */
        public static final int accessibility_custom_action_14 = 2131230738;
        /* added by JADX */
        public static final int accessibility_custom_action_15 = 2131230739;
        /* added by JADX */
        public static final int accessibility_custom_action_16 = 2131230740;
        /* added by JADX */
        public static final int accessibility_custom_action_17 = 2131230741;
        /* added by JADX */
        public static final int accessibility_custom_action_18 = 2131230742;
        /* added by JADX */
        public static final int accessibility_custom_action_19 = 2131230743;
        /* added by JADX */
        public static final int accessibility_custom_action_2 = 2131230744;
        /* added by JADX */
        public static final int accessibility_custom_action_20 = 2131230745;
        /* added by JADX */
        public static final int accessibility_custom_action_21 = 2131230746;
        /* added by JADX */
        public static final int accessibility_custom_action_22 = 2131230747;
        /* added by JADX */
        public static final int accessibility_custom_action_23 = 2131230748;
        /* added by JADX */
        public static final int accessibility_custom_action_24 = 2131230749;
        /* added by JADX */
        public static final int accessibility_custom_action_25 = 2131230750;
        /* added by JADX */
        public static final int accessibility_custom_action_26 = 2131230751;
        /* added by JADX */
        public static final int accessibility_custom_action_27 = 2131230752;
        /* added by JADX */
        public static final int accessibility_custom_action_28 = 2131230753;
        /* added by JADX */
        public static final int accessibility_custom_action_29 = 2131230754;
        /* added by JADX */
        public static final int accessibility_custom_action_3 = 2131230755;
        /* added by JADX */
        public static final int accessibility_custom_action_30 = 2131230756;
        /* added by JADX */
        public static final int accessibility_custom_action_31 = 2131230757;
        /* added by JADX */
        public static final int accessibility_custom_action_4 = 2131230758;
        /* added by JADX */
        public static final int accessibility_custom_action_5 = 2131230759;
        /* added by JADX */
        public static final int accessibility_custom_action_6 = 2131230760;
        /* added by JADX */
        public static final int accessibility_custom_action_7 = 2131230761;
        /* added by JADX */
        public static final int accessibility_custom_action_8 = 2131230762;
        /* added by JADX */
        public static final int accessibility_custom_action_9 = 2131230763;
        /* added by JADX */
        public static final int actionDown = 2131230764;
        /* added by JADX */
        public static final int actionDownUp = 2131230765;
        /* added by JADX */
        public static final int actionUp = 2131230766;
        /* added by JADX */
        public static final int action_bar = 2131230767;
        /* added by JADX */
        public static final int action_bar_activity_content = 2131230768;
        /* added by JADX */
        public static final int action_bar_container = 2131230769;
        /* added by JADX */
        public static final int action_bar_root = 2131230770;
        /* added by JADX */
        public static final int action_bar_spinner = 2131230771;
        /* added by JADX */
        public static final int action_bar_subtitle = 2131230772;
        /* added by JADX */
        public static final int action_bar_title = 2131230773;
        /* added by JADX */
        public static final int action_container = 2131230774;
        /* added by JADX */
        public static final int action_context_bar = 2131230775;
        /* added by JADX */
        public static final int action_divider = 2131230776;
        /* added by JADX */
        public static final int action_image = 2131230777;
        /* added by JADX */
        public static final int action_menu_divider = 2131230778;
        /* added by JADX */
        public static final int action_menu_presenter = 2131230779;
        /* added by JADX */
        public static final int action_mode_bar = 2131230780;
        /* added by JADX */
        public static final int action_mode_bar_stub = 2131230781;
        /* added by JADX */
        public static final int action_mode_close_button = 2131230782;
        /* added by JADX */
        public static final int action_text = 2131230783;
        /* added by JADX */
        public static final int actions = 2131230784;
        /* added by JADX */
        public static final int activity_chooser_view_content = 2131230785;
        /* added by JADX */
        public static final int add = 2131230786;
        /* added by JADX */
        public static final int alertTitle = 2131230787;
        /* added by JADX */
        public static final int aligned = 2131230788;
        /* added by JADX */
        public static final int allStates = 2131230789;
        /* added by JADX */
        public static final int always = 2131230790;
        /* added by JADX */
        public static final int animateToEnd = 2131230791;
        /* added by JADX */
        public static final int animateToStart = 2131230792;
        /* added by JADX */
        public static final int antiClockwise = 2131230793;
        /* added by JADX */
        public static final int anticipate = 2131230794;
        /* added by JADX */
        public static final int asConfigured = 2131230795;
        /* added by JADX */
        public static final int async = 2131230796;
        /* added by JADX */
        public static final int auto = 2131230797;
        /* added by JADX */
        public static final int autoComplete = 2131230798;
        /* added by JADX */
        public static final int autoCompleteToEnd = 2131230799;
        /* added by JADX */
        public static final int autoCompleteToStart = 2131230800;
        /* added by JADX */
        public static final int barrier = 2131230801;
        /* added by JADX */
        public static final int baseline = 2131230802;
        /* added by JADX */
        public static final int beginOnFirstDraw = 2131230803;
        /* added by JADX */
        public static final int beginning = 2131230804;
        /* added by JADX */
        public static final int bestChoice = 2131230805;
        /* added by JADX */
        public static final int blocking = 2131230806;
        /* added by JADX */
        public static final int bottom = 2131230807;
        /* added by JADX */
        public static final int bounce = 2131230808;
        /* added by JADX */
        public static final int bounceBoth = 2131230809;
        /* added by JADX */
        public static final int bounceEnd = 2131230810;
        /* added by JADX */
        public static final int bounceStart = 2131230811;
        /* added by JADX */
        public static final int buttonPanel = 2131230812;
        /* added by JADX */
        public static final int cache_measures = 2131230813;
        /* added by JADX */
        public static final int callMeasure = 2131230814;
        /* added by JADX */
        public static final int carryVelocity = 2131230815;
        /* added by JADX */
        public static final int center = 2131230816;
        /* added by JADX */
        public static final int center_vertical = 2131230817;
        /* added by JADX */
        public static final int chain = 2131230818;
        /* added by JADX */
        public static final int chain2 = 2131230819;
        /* added by JADX */
        public static final int chains = 2131230820;
        /* added by JADX */
        public static final int checkbox = 2131230821;
        /* added by JADX */
        public static final int checked = 2131230822;
        /* added by JADX */
        public static final int chronometer = 2131230823;
        /* added by JADX */
        public static final int clockwise = 2131230824;
        /* added by JADX */
        public static final int closest = 2131230825;
        /* added by JADX */
        public static final int collapseActionView = 2131230826;
        /* added by JADX */
        public static final int constraint = 2131230827;
        /* added by JADX */
        public static final int content = 2131230828;
        /* added by JADX */
        public static final int contentPanel = 2131230829;
        /* added by JADX */
        public static final int continuousVelocity = 2131230830;
        /* added by JADX */
        public static final int cos = 2131230831;
        /* added by JADX */
        public static final int currentState = 2131230832;
        /* added by JADX */
        public static final int custom = 2131230833;
        /* added by JADX */
        public static final int customPanel = 2131230834;
        /* added by JADX */
        public static final int decelerate = 2131230835;
        /* added by JADX */
        public static final int decelerateAndComplete = 2131230836;
        /* added by JADX */
        public static final int decor_content_parent = 2131230837;
        /* added by JADX */
        public static final int default_activity_button = 2131230838;
        /* added by JADX */
        public static final int deltaRelative = 2131230839;
        /* added by JADX */
        public static final int dependency_ordering = 2131230840;
        /* added by JADX */
        public static final int dialog_button = 2131230841;
        /* added by JADX */
        public static final int dimensions = 2131230842;
        /* added by JADX */
        public static final int direct = 2131230843;
        /* added by JADX */
        public static final int disableHome = 2131230844;
        /* added by JADX */
        public static final int disableIntraAutoTransition = 2131230845;
        /* added by JADX */
        public static final int disablePostScroll = 2131230846;
        /* added by JADX */
        public static final int disableScroll = 2131230847;
        /* added by JADX */
        public static final int dragAnticlockwise = 2131230848;
        /* added by JADX */
        public static final int dragClockwise = 2131230849;
        /* added by JADX */
        public static final int dragDown = 2131230850;
        /* added by JADX */
        public static final int dragEnd = 2131230851;
        /* added by JADX */
        public static final int dragLeft = 2131230852;
        /* added by JADX */
        public static final int dragRight = 2131230853;
        /* added by JADX */
        public static final int dragStart = 2131230854;
        /* added by JADX */
        public static final int dragUp = 2131230855;
        /* added by JADX */
        public static final int easeIn = 2131230856;
        /* added by JADX */
        public static final int easeInOut = 2131230857;
        /* added by JADX */
        public static final int easeOut = 2131230858;
        /* added by JADX */
        public static final int east = 2131230859;
        /* added by JADX */
        public static final int edit_query = 2131230860;
        /* added by JADX */
        public static final int end = 2131230861;
        /* added by JADX */
        public static final int expand_activities_button = 2131230862;
        /* added by JADX */
        public static final int expanded_menu = 2131230863;
        /* added by JADX */
        public static final int flip = 2131230864;
        /* added by JADX */
        public static final int forever = 2131230865;
        /* added by JADX */
        public static final int fragment_container_view_tag = 2131230866;
        /* added by JADX */
        public static final int frost = 2131230867;
        /* added by JADX */
        public static final int gone = 2131230868;
        /* added by JADX */
        public static final int graph = 2131230869;
        /* added by JADX */
        public static final int graph_wrap = 2131230870;
        /* added by JADX */
        public static final int group_divider = 2131230871;
        /* added by JADX */
        public static final int grouping = 2131230872;
        /* added by JADX */
        public static final int groups = 2131230873;
        /* added by JADX */
        public static final int home = 2131230874;
        /* added by JADX */
        public static final int homeAsUp = 2131230875;
        /* added by JADX */
        public static final int honorRequest = 2131230876;
        /* added by JADX */
        public static final int horizontal_only = 2131230877;
        /* added by JADX */
        public static final int icon = 2131230878;
        /* added by JADX */
        public static final int icon_group = 2131230879;
        /* added by JADX */
        public static final int ifRoom = 2131230880;
        /* added by JADX */
        public static final int ignore = 2131230881;
        /* added by JADX */
        public static final int ignoreRequest = 2131230882;
        /* added by JADX */
        public static final int image = 2131230883;
        /* added by JADX */
        public static final int immediateStop = 2131230884;
        /* added by JADX */
        public static final int included = 2131230885;
        /* added by JADX */
        public static final int info = 2131230886;
        /* added by JADX */
        public static final int invisible = 2131230887;
        /* added by JADX */
        public static final int italic = 2131230888;
        /* added by JADX */
        public static final int jumpToEnd = 2131230889;
        /* added by JADX */
        public static final int jumpToStart = 2131230890;
        /* added by JADX */
        public static final int layout = 2131230891;
        /* added by JADX */
        public static final int left = 2131230892;
        /* added by JADX */
        public static final int legacy = 2131230893;
        /* added by JADX */
        public static final int line1 = 2131230894;
        /* added by JADX */
        public static final int line3 = 2131230895;
        /* added by JADX */
        public static final int linear = 2131230896;
        /* added by JADX */
        public static final int listMode = 2131230897;
        /* added by JADX */
        public static final int list_item = 2131230898;
        /* added by JADX */
        public static final int match_constraint = 2131230899;
        /* added by JADX */
        public static final int match_parent = 2131230900;
        /* added by JADX */
        public static final int message = 2131230901;
        /* added by JADX */
        public static final int middle = 2131230902;
        /* added by JADX */
        public static final int motion_base = 2131230903;
        /* added by JADX */
        public static final int multiply = 2131230904;
        /* added by JADX */
        public static final int never = 2131230905;
        /* added by JADX */
        public static final int neverCompleteToEnd = 2131230906;
        /* added by JADX */
        public static final int neverCompleteToStart = 2131230907;
        /* added by JADX */
        public static final int noState = 2131230908;
        /* added by JADX */
        public static final int none = 2131230909;
        /* added by JADX */
        public static final int normal = 2131230910;
        /* added by JADX */
        public static final int north = 2131230911;
        /* added by JADX */
        public static final int notification_background = 2131230912;
        /* added by JADX */
        public static final int notification_main_column = 2131230913;
        /* added by JADX */
        public static final int notification_main_column_container = 2131230914;
        /* added by JADX */
        public static final int off = 2131230915;
        /* added by JADX */
        public static final int on = 2131230916;
        /* added by JADX */
        public static final int onInterceptTouchReturnSwipe = 2131230917;
        /* added by JADX */
        public static final int overshoot = 2131230918;
        /* added by JADX */
        public static final int packed = 2131230919;
        /* added by JADX */
        public static final int parent = 2131230920;
        /* added by JADX */
        public static final int parentPanel = 2131230921;
        /* added by JADX */
        public static final int parentRelative = 2131230922;
        /* added by JADX */
        public static final int path = 2131230923;
        /* added by JADX */
        public static final int pathRelative = 2131230924;
        /* added by JADX */
        public static final int percent = 2131230925;
        /* added by JADX */
        public static final int position = 2131230926;
        /* added by JADX */
        public static final int postLayout = 2131230927;
        /* added by JADX */
        public static final int progress_circular = 2131230928;
        /* added by JADX */
        public static final int progress_horizontal = 2131230929;
        /* added by JADX */
        public static final int radio = 2131230930;
        /* added by JADX */
        public static final int ratio = 2131230931;
        /* added by JADX */
        public static final int rectangles = 2131230932;
        /* added by JADX */
        public static final int reverseSawtooth = 2131230933;
        /* added by JADX */
        public static final int right = 2131230934;
        /* added by JADX */
        public static final int right_icon = 2131230935;
        /* added by JADX */
        public static final int right_side = 2131230936;
        /* added by JADX */
        public static final int sawtooth = 2131230937;
        /* added by JADX */
        public static final int screen = 2131230938;
        /* added by JADX */
        public static final int scrollIndicatorDown = 2131230939;
        /* added by JADX */
        public static final int scrollIndicatorUp = 2131230940;
        /* added by JADX */
        public static final int scrollView = 2131230941;
        /* added by JADX */
        public static final int search_badge = 2131230942;
        /* added by JADX */
        public static final int search_bar = 2131230943;
        /* added by JADX */
        public static final int search_button = 2131230944;
        /* added by JADX */
        public static final int search_close_btn = 2131230945;
        /* added by JADX */
        public static final int search_edit_frame = 2131230946;
        /* added by JADX */
        public static final int search_go_btn = 2131230947;
        /* added by JADX */
        public static final int search_mag_icon = 2131230948;
        /* added by JADX */
        public static final int search_plate = 2131230949;
        /* added by JADX */
        public static final int search_src_text = 2131230950;
        /* added by JADX */
        public static final int search_voice_btn = 2131230951;
        /* added by JADX */
        public static final int select_dialog_listview = 2131230952;
        /* added by JADX */
        public static final int sharedValueSet = 2131230953;
        /* added by JADX */
        public static final int sharedValueUnset = 2131230954;
        /* added by JADX */
        public static final int shortcut = 2131230955;
        /* added by JADX */
        public static final int showCustom = 2131230956;
        /* added by JADX */
        public static final int showHome = 2131230957;
        /* added by JADX */
        public static final int showTitle = 2131230958;
        /* added by JADX */
        public static final int sin = 2131230959;
        /* added by JADX */
        public static final int skipped = 2131230960;
        /* added by JADX */
        public static final int south = 2131230961;
        /* added by JADX */
        public static final int spacer = 2131230962;
        /* added by JADX */
        public static final int special_effects_controller_view_tag = 2131230963;
        /* added by JADX */
        public static final int spline = 2131230964;
        /* added by JADX */
        public static final int split_action_bar = 2131230965;
        /* added by JADX */
        public static final int spread = 2131230966;
        /* added by JADX */
        public static final int spread_inside = 2131230967;
        /* added by JADX */
        public static final int spring = 2131230968;
        /* added by JADX */
        public static final int square = 2131230969;
        /* added by JADX */
        public static final int src_atop = 2131230970;
        /* added by JADX */
        public static final int src_in = 2131230971;
        /* added by JADX */
        public static final int src_over = 2131230972;
        /* added by JADX */
        public static final int standard = 2131230973;
        /* added by JADX */
        public static final int start = 2131230974;
        /* added by JADX */
        public static final int startHorizontal = 2131230975;
        /* added by JADX */
        public static final int startVertical = 2131230976;
        /* added by JADX */
        public static final int staticLayout = 2131230977;
        /* added by JADX */
        public static final int staticPostLayout = 2131230978;
        /* added by JADX */
        public static final int stop = 2131230979;
        /* added by JADX */
        public static final int submenuarrow = 2131230980;
        /* added by JADX */
        public static final int submit_area = 2131230981;
        /* added by JADX */
        public static final int supportScrollUp = 2131230982;
        /* added by JADX */
        public static final int tabMode = 2131230983;
        /* added by JADX */
        public static final int tag_accessibility_actions = 2131230984;
        /* added by JADX */
        public static final int tag_accessibility_clickable_spans = 2131230985;
        /* added by JADX */
        public static final int tag_accessibility_heading = 2131230986;
        /* added by JADX */
        public static final int tag_accessibility_pane_title = 2131230987;
        /* added by JADX */
        public static final int tag_on_apply_window_listener = 2131230988;
        /* added by JADX */
        public static final int tag_on_receive_content_listener = 2131230989;
        /* added by JADX */
        public static final int tag_on_receive_content_mime_types = 2131230990;
        /* added by JADX */
        public static final int tag_screen_reader_focusable = 2131230991;
        /* added by JADX */
        public static final int tag_state_description = 2131230992;
        /* added by JADX */
        public static final int tag_transition_group = 2131230993;
        /* added by JADX */
        public static final int tag_unhandled_key_event_manager = 2131230994;
        /* added by JADX */
        public static final int tag_unhandled_key_listeners = 2131230995;
        /* added by JADX */
        public static final int tag_window_insets_animation_callback = 2131230996;
        /* added by JADX */
        public static final int text = 2131230997;
        /* added by JADX */
        public static final int text2 = 2131230998;
        /* added by JADX */
        public static final int textSpacerNoButtons = 2131230999;
        /* added by JADX */
        public static final int textSpacerNoTitle = 2131231000;
        /* added by JADX */
        public static final int time = 2131231001;
        /* added by JADX */
        public static final int title = 2131231002;
        /* added by JADX */
        public static final int titleDividerNoCustom = 2131231003;
        /* added by JADX */
        public static final int title_template = 2131231004;
        /* added by JADX */
        public static final int toggle = 2131231005;
        /* added by JADX */
        public static final int top = 2131231006;
        /* added by JADX */
        public static final int topPanel = 2131231007;
        /* added by JADX */
        public static final int transitionToEnd = 2131231008;
        /* added by JADX */
        public static final int transitionToStart = 2131231009;
        /* added by JADX */
        public static final int triangle = 2131231010;
        /* added by JADX */
        public static final int unchecked = 2131231011;
        /* added by JADX */
        public static final int uniform = 2131231012;
        /* added by JADX */
        public static final int unitySurfaceView = 2131231013;
        /* added by JADX */
        public static final int up = 2131231014;
        /* added by JADX */
        public static final int useLogo = 2131231015;
        /* added by JADX */
        public static final int vertical_only = 2131231016;
        /* added by JADX */
        public static final int view_transition = 2131231017;
        /* added by JADX */
        public static final int view_tree_lifecycle_owner = 2131231018;
        /* added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 2131231019;
        /* added by JADX */
        public static final int view_tree_saved_state_registry_owner = 2131231020;
        /* added by JADX */
        public static final int view_tree_view_model_store_owner = 2131231021;
        /* added by JADX */
        public static final int visible = 2131231022;
        /* added by JADX */
        public static final int visible_removing_fragment_view_tag = 2131231023;
        /* added by JADX */
        public static final int west = 2131231024;
        /* added by JADX */
        public static final int withText = 2131231025;
        /* added by JADX */
        public static final int wrap = 2131231026;
        /* added by JADX */
        public static final int wrap_content = 2131231027;
        /* added by JADX */
        public static final int wrap_content_constrained = 2131231028;
        /* added by JADX */
        public static final int x_left = 2131231029;
        /* added by JADX */
        public static final int x_right = 2131231030;
    }

    /* added by JADX */
    public static final class integer {
        /* added by JADX */
        public static final int abc_config_activityDefaultDur = 2131296256;
        /* added by JADX */
        public static final int abc_config_activityShortDur = 2131296257;
        /* added by JADX */
        public static final int cancel_button_image_alpha = 2131296258;
        /* added by JADX */
        public static final int config_tooltipAnimTime = 2131296259;
        /* added by JADX */
        public static final int status_bar_notification_info_maxnum = 2131296260;
    }

    /* added by JADX */
    public static final class interpolator {
        /* added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131361792;
        /* added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131361793;
        /* added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131361794;
        /* added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131361795;
        /* added by JADX */
        public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131361796;
        /* added by JADX */
        public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131361797;
        /* added by JADX */
        public static final int fast_out_slow_in = 2131361798;
    }

    /* added by JADX */
    public static final class layout {
        /* added by JADX */
        public static final int abc_action_bar_title_item = 2131427328;
        /* added by JADX */
        public static final int abc_action_bar_up_container = 2131427329;
        /* added by JADX */
        public static final int abc_action_menu_item_layout = 2131427330;
        /* added by JADX */
        public static final int abc_action_menu_layout = 2131427331;
        /* added by JADX */
        public static final int abc_action_mode_bar = 2131427332;
        /* added by JADX */
        public static final int abc_action_mode_close_item_material = 2131427333;
        /* added by JADX */
        public static final int abc_activity_chooser_view = 2131427334;
        /* added by JADX */
        public static final int abc_activity_chooser_view_list_item = 2131427335;
        /* added by JADX */
        public static final int abc_alert_dialog_button_bar_material = 2131427336;
        /* added by JADX */
        public static final int abc_alert_dialog_material = 2131427337;
        /* added by JADX */
        public static final int abc_alert_dialog_title_material = 2131427338;
        /* added by JADX */
        public static final int abc_cascading_menu_item_layout = 2131427339;
        /* added by JADX */
        public static final int abc_dialog_title_material = 2131427340;
        /* added by JADX */
        public static final int abc_expanded_menu_layout = 2131427341;
        /* added by JADX */
        public static final int abc_list_menu_item_checkbox = 2131427342;
        /* added by JADX */
        public static final int abc_list_menu_item_icon = 2131427343;
        /* added by JADX */
        public static final int abc_list_menu_item_layout = 2131427344;
        /* added by JADX */
        public static final int abc_list_menu_item_radio = 2131427345;
        /* added by JADX */
        public static final int abc_popup_menu_header_item_layout = 2131427346;
        /* added by JADX */
        public static final int abc_popup_menu_item_layout = 2131427347;
        /* added by JADX */
        public static final int abc_screen_content_include = 2131427348;
        /* added by JADX */
        public static final int abc_screen_simple = 2131427349;
        /* added by JADX */
        public static final int abc_screen_simple_overlay_action_mode = 2131427350;
        /* added by JADX */
        public static final int abc_screen_toolbar = 2131427351;
        /* added by JADX */
        public static final int abc_search_dropdown_item_icons_2line = 2131427352;
        /* added by JADX */
        public static final int abc_search_view = 2131427353;
        /* added by JADX */
        public static final int abc_select_dialog_material = 2131427354;
        /* added by JADX */
        public static final int abc_tooltip = 2131427355;
        /* added by JADX */
        public static final int custom_dialog = 2131427356;
        /* added by JADX */
        public static final int notification_action = 2131427357;
        /* added by JADX */
        public static final int notification_action_tombstone = 2131427358;
        /* added by JADX */
        public static final int notification_template_custom_big = 2131427359;
        /* added by JADX */
        public static final int notification_template_icon_group = 2131427360;
        /* added by JADX */
        public static final int notification_template_part_chronometer = 2131427361;
        /* added by JADX */
        public static final int notification_template_part_time = 2131427362;
        /* added by JADX */
        public static final int select_dialog_item_material = 2131427363;
        /* added by JADX */
        public static final int select_dialog_multichoice_material = 2131427364;
        /* added by JADX */
        public static final int select_dialog_singlechoice_material = 2131427365;
        /* added by JADX */
        public static final int support_simple_spinner_dropdown_item = 2131427366;
    }

    /* added by JADX */
    public static final class style {
        /* added by JADX */
        public static final int AlertDialog_AppCompat = 2131623936;
        /* added by JADX */
        public static final int AlertDialog_AppCompat_Light = 2131623937;
        /* added by JADX */
        public static final int Animation_AppCompat_Dialog = 2131623938;
        /* added by JADX */
        public static final int Animation_AppCompat_DropDownUp = 2131623939;
        /* added by JADX */
        public static final int Animation_AppCompat_Tooltip = 2131623940;
        /* added by JADX */
        public static final int Base_AlertDialog_AppCompat = 2131623941;
        /* added by JADX */
        public static final int Base_AlertDialog_AppCompat_Light = 2131623942;
        /* added by JADX */
        public static final int Base_Animation_AppCompat_Dialog = 2131623943;
        /* added by JADX */
        public static final int Base_Animation_AppCompat_DropDownUp = 2131623944;
        /* added by JADX */
        public static final int Base_Animation_AppCompat_Tooltip = 2131623945;
        /* added by JADX */
        public static final int Base_DialogWindowTitle_AppCompat = 2131623946;
        /* added by JADX */
        public static final int Base_DialogWindowTitleBackground_AppCompat = 2131623947;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat = 2131623948;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body1 = 2131623949;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body2 = 2131623950;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Button = 2131623951;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Caption = 2131623952;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display1 = 2131623953;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display2 = 2131623954;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display3 = 2131623955;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display4 = 2131623956;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Headline = 2131623957;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Inverse = 2131623958;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large = 2131623959;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131623960;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131623961;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131623962;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium = 2131623963;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131623964;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Menu = 2131623965;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult = 2131623966;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131623967;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131623968;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small = 2131623969;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131623970;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead = 2131623971;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131623972;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title = 2131623973;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131623974;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Tooltip = 2131623975;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131623976;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131623977;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131623978;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131623979;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131623980;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131623981;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131623982;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131623983;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131623984;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131623985;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131623986;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131623987;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131623988;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131623989;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131623990;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131623991;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131623992;
        /* added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131623993;
        /* added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131623994;
        /* added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131623995;
        /* added by JADX */
        public static final int Base_Theme_AppCompat = 2131623996;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_CompactMenu = 2131623997;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Dialog = 2131623998;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_Alert = 2131623999;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131624000;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131624001;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131624002;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light = 2131624003;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131624004;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog = 2131624005;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131624006;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131624007;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131624008;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131624009;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat = 2131624010;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131624011;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark = 2131624012;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131624013;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131624014;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131624015;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Light = 2131624016;
        /* added by JADX */
        public static final int Base_V21_Theme_AppCompat = 2131624017;
        /* added by JADX */
        public static final int Base_V21_Theme_AppCompat_Dialog = 2131624018;
        /* added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light = 2131624019;
        /* added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131624020;
        /* added by JADX */
        public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131624021;
        /* added by JADX */
        public static final int Base_V22_Theme_AppCompat = 2131624022;
        /* added by JADX */
        public static final int Base_V22_Theme_AppCompat_Light = 2131624023;
        /* added by JADX */
        public static final int Base_V23_Theme_AppCompat = 2131624024;
        /* added by JADX */
        public static final int Base_V23_Theme_AppCompat_Light = 2131624025;
        /* added by JADX */
        public static final int Base_V26_Theme_AppCompat = 2131624026;
        /* added by JADX */
        public static final int Base_V26_Theme_AppCompat_Light = 2131624027;
        /* added by JADX */
        public static final int Base_V26_Widget_AppCompat_Toolbar = 2131624028;
        /* added by JADX */
        public static final int Base_V28_Theme_AppCompat = 2131624029;
        /* added by JADX */
        public static final int Base_V28_Theme_AppCompat_Light = 2131624030;
        /* added by JADX */
        public static final int Base_V7_Theme_AppCompat = 2131624031;
        /* added by JADX */
        public static final int Base_V7_Theme_AppCompat_Dialog = 2131624032;
        /* added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light = 2131624033;
        /* added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131624034;
        /* added by JADX */
        public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131624035;
        /* added by JADX */
        public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131624036;
        /* added by JADX */
        public static final int Base_V7_Widget_AppCompat_EditText = 2131624037;
        /* added by JADX */
        public static final int Base_V7_Widget_AppCompat_Toolbar = 2131624038;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar = 2131624039;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131624040;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131624041;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131624042;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131624043;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton = 2131624044;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131624045;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131624046;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionMode = 2131624047;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActivityChooserView = 2131624048;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131624049;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button = 2131624050;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless = 2131624051;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131624052;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131624053;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_Colored = 2131624054;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_Small = 2131624055;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar = 2131624056;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131624057;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131624058;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131624059;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131624060;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131624061;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131624062;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131624063;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_EditText = 2131624064;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ImageButton = 2131624065;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar = 2131624066;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131624067;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131624068;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131624069;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131624070;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131624071;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131624072;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131624073;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListMenuView = 2131624074;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListPopupWindow = 2131624075;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListView = 2131624076;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListView_DropDown = 2131624077;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListView_Menu = 2131624078;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu = 2131624079;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131624080;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_PopupWindow = 2131624081;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar = 2131624082;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131624083;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar = 2131624084;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131624085;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Small = 2131624086;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_SearchView = 2131624087;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131624088;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar = 2131624089;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131624090;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Spinner = 2131624091;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131624092;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_TextView = 2131624093;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131624094;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar = 2131624095;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131624096;
        /* added by JADX */
        public static final int BaseUnityGameActivityTheme = 2131624097;
        /* added by JADX */
        public static final int BaseUnityTheme = 2131624098;
        /* added by JADX */
        public static final int Platform_AppCompat = 2131624099;
        /* added by JADX */
        public static final int Platform_AppCompat_Light = 2131624100;
        /* added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat = 2131624101;
        /* added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131624102;
        /* added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Light = 2131624103;
        /* added by JADX */
        public static final int Platform_V21_AppCompat = 2131624104;
        /* added by JADX */
        public static final int Platform_V21_AppCompat_Light = 2131624105;
        /* added by JADX */
        public static final int Platform_V25_AppCompat = 2131624106;
        /* added by JADX */
        public static final int Platform_V25_AppCompat_Light = 2131624107;
        /* added by JADX */
        public static final int Platform_Widget_AppCompat_Spinner = 2131624108;
        /* added by JADX */
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131624109;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131624110;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131624111;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131624112;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131624113;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131624114;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131624115;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131624116;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131624117;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131624118;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131624119;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131624120;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131624121;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131624122;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131624123;
        /* added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131624124;
        /* added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131624125;
        /* added by JADX */
        public static final int TextAppearance_AppCompat = 2131624126;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Body1 = 2131624127;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Body2 = 2131624128;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Button = 2131624129;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Caption = 2131624130;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Display1 = 2131624131;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Display2 = 2131624132;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Display3 = 2131624133;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Display4 = 2131624134;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Headline = 2131624135;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Inverse = 2131624136;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Large = 2131624137;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Large_Inverse = 2131624138;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131624139;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131624140;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131624141;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131624142;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Medium = 2131624143;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Medium_Inverse = 2131624144;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Menu = 2131624145;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131624146;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Title = 2131624147;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Small = 2131624148;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Small_Inverse = 2131624149;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Subhead = 2131624150;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131624151;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Title = 2131624152;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Title_Inverse = 2131624153;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Tooltip = 2131624154;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131624155;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131624156;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131624157;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131624158;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131624159;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131624160;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131624161;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131624162;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131624163;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button = 2131624164;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131624165;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131624166;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131624167;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131624168;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131624169;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131624170;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131624171;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Switch = 2131624172;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131624173;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification = 2131624174;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 2131624175;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 2131624176;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 2131624177;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 2131624178;
        /* added by JADX */
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131624179;
        /* added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131624180;
        /* added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131624181;
        /* added by JADX */
        public static final int Theme_AppCompat = 2131624182;
        /* added by JADX */
        public static final int Theme_AppCompat_CompactMenu = 2131624183;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight = 2131624184;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131624185;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog = 2131624186;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131624187;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131624188;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131624189;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_NoActionBar = 2131624190;
        /* added by JADX */
        public static final int Theme_AppCompat_Dialog = 2131624191;
        /* added by JADX */
        public static final int Theme_AppCompat_Dialog_Alert = 2131624192;
        /* added by JADX */
        public static final int Theme_AppCompat_Dialog_MinWidth = 2131624193;
        /* added by JADX */
        public static final int Theme_AppCompat_DialogWhenLarge = 2131624194;
        /* added by JADX */
        public static final int Theme_AppCompat_Empty = 2131624195;
        /* added by JADX */
        public static final int Theme_AppCompat_Light = 2131624196;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_DarkActionBar = 2131624197;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_Dialog = 2131624198;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_Alert = 2131624199;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131624200;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131624201;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_NoActionBar = 2131624202;
        /* added by JADX */
        public static final int Theme_AppCompat_NoActionBar = 2131624203;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat = 2131624204;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_ActionBar = 2131624205;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark = 2131624206;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131624207;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight = 2131624208;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131624209;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog = 2131624210;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131624211;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Light = 2131624212;
        /* added by JADX */
        public static final int UnityThemeSelector = 2131624213;
        /* added by JADX */
        public static final int UnityThemeSelector_Translucent = 2131624214;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar = 2131624215;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar_Solid = 2131624216;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabBar = 2131624217;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabText = 2131624218;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabView = 2131624219;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionButton = 2131624220;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionButton_CloseMode = 2131624221;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionButton_Overflow = 2131624222;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionMode = 2131624223;
        /* added by JADX */
        public static final int Widget_AppCompat_ActivityChooserView = 2131624224;
        /* added by JADX */
        public static final int Widget_AppCompat_AutoCompleteTextView = 2131624225;
        /* added by JADX */
        public static final int Widget_AppCompat_Button = 2131624226;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_Borderless = 2131624227;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_Borderless_Colored = 2131624228;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131624229;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_Colored = 2131624230;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_Small = 2131624231;
        /* added by JADX */
        public static final int Widget_AppCompat_ButtonBar = 2131624232;
        /* added by JADX */
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131624233;
        /* added by JADX */
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131624234;
        /* added by JADX */
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131624235;
        /* added by JADX */
        public static final int Widget_AppCompat_CompoundButton_Switch = 2131624236;
        /* added by JADX */
        public static final int Widget_AppCompat_DrawerArrowToggle = 2131624237;
        /* added by JADX */
        public static final int Widget_AppCompat_DropDownItem_Spinner = 2131624238;
        /* added by JADX */
        public static final int Widget_AppCompat_EditText = 2131624239;
        /* added by JADX */
        public static final int Widget_AppCompat_ImageButton = 2131624240;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar = 2131624241;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131624242;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131624243;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131624244;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131624245;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131624246;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131624247;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131624248;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131624249;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton = 2131624250;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131624251;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131624252;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131624253;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActivityChooserView = 2131624254;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131624255;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131624256;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ListPopupWindow = 2131624257;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ListView_DropDown = 2131624258;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu = 2131624259;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131624260;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_SearchView = 2131624261;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131624262;
        /* added by JADX */
        public static final int Widget_AppCompat_ListMenuView = 2131624263;
        /* added by JADX */
        public static final int Widget_AppCompat_ListPopupWindow = 2131624264;
        /* added by JADX */
        public static final int Widget_AppCompat_ListView = 2131624265;
        /* added by JADX */
        public static final int Widget_AppCompat_ListView_DropDown = 2131624266;
        /* added by JADX */
        public static final int Widget_AppCompat_ListView_Menu = 2131624267;
        /* added by JADX */
        public static final int Widget_AppCompat_PopupMenu = 2131624268;
        /* added by JADX */
        public static final int Widget_AppCompat_PopupMenu_Overflow = 2131624269;
        /* added by JADX */
        public static final int Widget_AppCompat_PopupWindow = 2131624270;
        /* added by JADX */
        public static final int Widget_AppCompat_ProgressBar = 2131624271;
        /* added by JADX */
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131624272;
        /* added by JADX */
        public static final int Widget_AppCompat_RatingBar = 2131624273;
        /* added by JADX */
        public static final int Widget_AppCompat_RatingBar_Indicator = 2131624274;
        /* added by JADX */
        public static final int Widget_AppCompat_RatingBar_Small = 2131624275;
        /* added by JADX */
        public static final int Widget_AppCompat_SearchView = 2131624276;
        /* added by JADX */
        public static final int Widget_AppCompat_SearchView_ActionBar = 2131624277;
        /* added by JADX */
        public static final int Widget_AppCompat_SeekBar = 2131624278;
        /* added by JADX */
        public static final int Widget_AppCompat_SeekBar_Discrete = 2131624279;
        /* added by JADX */
        public static final int Widget_AppCompat_Spinner = 2131624280;
        /* added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown = 2131624281;
        /* added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131624282;
        /* added by JADX */
        public static final int Widget_AppCompat_Spinner_Underlined = 2131624283;
        /* added by JADX */
        public static final int Widget_AppCompat_TextView = 2131624284;
        /* added by JADX */
        public static final int Widget_AppCompat_TextView_SpinnerItem = 2131624285;
        /* added by JADX */
        public static final int Widget_AppCompat_Toolbar = 2131624286;
        /* added by JADX */
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131624287;
        /* added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 2131624288;
        /* added by JADX */
        public static final int Widget_Compat_NotificationActionText = 2131624289;
    }

    private R() {
    }
}
