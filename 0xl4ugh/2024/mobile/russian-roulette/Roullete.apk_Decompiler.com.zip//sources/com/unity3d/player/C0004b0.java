package com.unity3d.player;

/* renamed from: com.unity3d.player.b0  reason: case insensitive filesystem */
public interface C0004b0 {
}
