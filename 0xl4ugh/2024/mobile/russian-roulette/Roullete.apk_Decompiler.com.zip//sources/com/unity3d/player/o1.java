package com.unity3d.player;

final class o1 implements D {
    final /* synthetic */ p1 a;

    o1(p1 p1Var) {
        this.a = p1Var;
    }

    public final void a() {
        this.a.m.nativeSoftInputLostFocus();
        this.a.m.reportSoftInputStr((String) null, 1, false);
    }
}
