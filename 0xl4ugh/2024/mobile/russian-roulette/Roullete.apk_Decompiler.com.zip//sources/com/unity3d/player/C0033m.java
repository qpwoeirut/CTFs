package com.unity3d.player;

/* renamed from: com.unity3d.player.m  reason: case insensitive filesystem */
public interface C0033m {
    void onAudioVolumeChanged(int i);
}
