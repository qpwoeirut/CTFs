package com.unity3d.player;

final class I0 implements G1 {
    final /* synthetic */ UnityPlayer a;

    I0(UnityPlayer unityPlayer) {
        this.a = unityPlayer;
    }

    public final void a() {
        this.a.mVideoPlayerProxy = null;
    }
}
