package com.unity3d.player;

public interface IUnityPlayerSupport {
    UnityPlayer getUnityPlayerConnection();
}
