package com.unity3d.player;

public interface IUnityPermissionRequestSupport {
    void requestPermissions(PermissionRequest permissionRequest);
}
