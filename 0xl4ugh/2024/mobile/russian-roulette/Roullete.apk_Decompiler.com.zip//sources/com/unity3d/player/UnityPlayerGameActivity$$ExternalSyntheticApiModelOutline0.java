package com.unity3d.player;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class UnityPlayerGameActivity$$ExternalSyntheticApiModelOutline0 {
}
