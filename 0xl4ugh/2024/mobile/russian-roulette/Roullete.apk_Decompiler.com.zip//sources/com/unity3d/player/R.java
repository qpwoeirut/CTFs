package com.unity3d.player;

public final class R {

    public static final class color {
        public static int staticSplashScreenBackgroundColor = 2131034191;

        private color() {
        }
    }

    public static final class id {
        public static int unitySurfaceView = 2131231013;

        private id() {
        }
    }

    public static final class string {
        public static int FreeformWindowOrientation_landscape = 2131558400;
        public static int FreeformWindowOrientation_portrait = 2131558401;
        public static int FreeformWindowSize_maximize = 2131558402;
        public static int FreeformWindowSize_phone = 2131558403;
        public static int FreeformWindowSize_tablet = 2131558404;
        public static int game_view_content_description = 2131558434;

        private string() {
        }
    }

    public static final class style {
        public static int BaseUnityGameActivityTheme = 2131624097;
        public static int BaseUnityTheme = 2131624098;
        public static int UnityThemeSelector = 2131624213;
        public static int UnityThemeSelector_Translucent = 2131624214;

        private style() {
        }
    }

    private R() {
    }
}
