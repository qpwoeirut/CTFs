package com.unity3d.player;

interface IAssetPackManagerMobileDataConfirmationCallback {
    void onMobileDataConfirmationResult(boolean z);
}
